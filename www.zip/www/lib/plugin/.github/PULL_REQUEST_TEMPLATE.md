## Changes
- (changes here)

## How To Test
- (necessary config changes)
- (necessary corresponding PRs)
- (how to access the new / changed functionality -- fixtures, URLs)

## Applicable Research Resources
- (links, optional)

## TODOs:
- [ ] +1
- [ ] Passes tests locally (`npm test`)
- [ ] Passes tests on CircleCI
- [ ] Updated README
- [ ] Updated CHANGELOG

Reminder: [Be excellent to each other](https://github.com/mobify/developer-values#be-excellent-to-each-other). Follow [these guidelines](https://www.djangoproject.com/conduct/) to help you do that when giving feedback!

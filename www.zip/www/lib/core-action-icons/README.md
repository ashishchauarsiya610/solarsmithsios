core-action-icons
=================

This is a _resource_ component which contains image assets for the default core icon set.

While HTML, JS, and CSS can be combined for production deployments by tools like Vulcanizer, some assets are easier to deliver as is. 

Projects using the default core icon set should include this component in deployments verbatim.

// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('starter', ['ionic'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs).
    // The reason we default this to hidden is that native apps don't usually show an accessory bar, at
    // least on iOS. It's a dead giveaway that an app is using a Web View. However, it's sometimes
    // useful especially with forms, though we would prefer giving the user a little more room
    // to interact with the app.
    if (window.cordova && window.Keyboard) {
      window.Keyboard.hideKeyboardAccessoryBar(true);
    }

    if (window.StatusBar) {
      // Set the statusbar to use the default style, tweak this to
      // remove the status bar on iOS or change it to use white instead of dark colors.
      StatusBar.styleDefault();
    }
  });
})

var solarApp = angular.module('starter', ['ionic', 'ui.router']);

solarApp.config(function ($stateProvider, $urlRouterProvider) {
  $stateProvider
  .state('app', {
    url: "/app",
    cache: false,
    abstract: true,
    templateUrl: "templates/menu.html",
    controller: 'appCtrl'
  })
  .state('app.home', {
    url: '/home',
    cache: false,
    views: {
      'menuContent': {
        templateUrl: 'templates/home.html',
        controller: 'appCtrl'
      }
    }
  })
  .state('app.ticket', {
    url: '/ticket',
    cache: false,
    views: {
      'menuContent': {
        templateUrl: 'templates/ticket.html',
        controller: 'appCtrl'
      }
    }
  })
  .state('app.certificate', {
    url: '/certificate',
    cache: false,
    views: {
      'menuContent': {
        templateUrl: 'templates/certificate.html',
        controller: 'appCtrl'
      }
    }
  })
  .state('app.chat-list', {
    url: '/chat-list',
    cache: false,
    views: {
      'menuContent': {
        templateUrl: 'templates/chat-list.html',
        controller: 'appCtrl'
      }
    }
  })
  .state('channel-partner', {
    url: '/channel-partner',
    templateUrl: 'templates/channel-partner.html',
    controller: 'appCtrl'
   })
  .state('login', {
    url: '/login',
    templateUrl: 'templates/login.html',
    controller: 'appCtrl'
   });
  $urlRouterProvider.otherwise("login");
});

solarApp.controller('appCtrl',function($scope,$state,$rootScope,$http,$httpParamSerializerJQLike){
  $rootScope.per="20";
  $rootScope.elogin=true;
	$scope.goTest=function(){
	  $state.go('login');
	}
	$scope.ticket=function(){
	  $state.go('app.ticket');
	}
	$scope.certificate=function(){
	  $state.go('app.certificate');
	}
	$scope.chatList=function(){
	  $state.go('app.chat-list');
	}
	$scope.channelPartner=function(){
	  $state.go('channel-partner');
  }
  $scope.clientLogin = function (Cid,Cpass) {
    var login_data = {};
    var datas = {
      user_name: Cid,
      password: Cpass
    };

    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/login",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: $httpParamSerializerJQLike(datas),
      dataType: "json"
    }).then(function mySuccess(response) {
      alert(JSON.stringify(response));
      if(response.data.status==false){
        $rootScope.elogin=false;
      }else{
      $rootScope.testData=response.data;
      $rootScope.loginData=$rootScope.testData.login;
      $rootScope.sites=$rootScope.loginData.sites;
      $scope.firstSite=$rootScope.sites[0].site_key;
      $rootScope.loginToken=$rootScope.loginData.token;
      $scope.getSites($scope.firstSite);
      
    }
    }, function myError(response) {
        alert(JSON.stringify(response));
      $rootScope.elogin=false;

    })

  };
  $scope.getSites=function(siteKey){
    $scope.newKey=siteKey;
   var token = $rootScope.loginToken;
  

    $http({
      method: "GET",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/sites?site_key="+$scope.newKey,
      headers: {
        'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Auth-Token' : token
      },
      dataType: "json"
    }).then(function mySuccess(response) {
      $rootScope.owner=response.data.site.owner;
      $state.go('app.home');
      $scope.getSitesData();
     
    }, function myError(response) {
      
    })
  }
  $scope.getSitesData=function(){
    
    var token = $rootScope.loginToken;
    $rootScope.sitesData=[
      {
       'siteKey':""
      }
    ];

    var outputdata = [];

      for (i = 0; i < (Object.keys($rootScope.sites).length); i++) {
       // $rootScope.sitesData[i].siteKey=$rootScope.sites[i].site_key;
        var key=$rootScope.sites[i].site_key;
        alert(key);
        $http({
          method: "GET",
          url: "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key="+key+"&from_date=22-08-2019&to_date=24-08-2019&time_grouping=day&group_type=max&data_type=Daily Energy",
          headers: {
            'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8',
            'X-Auth-Token' : token
          },
          dataType: "json"
        }).then(function mySuccess(response) {
          outputdata.push(response)
            alert(JSON.stringify(response));
            alert(JSON.stringify(outputdata));
         console.log(responce);
        }, function myError(response) {
            alert(JSON.stringify(response));
          
        })
        
      }
 

    //$state.go('app.home');
  }
});


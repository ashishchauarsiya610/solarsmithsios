// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
angular.module('starter', ['ionic', 'ngCordova', 'chart.js'])



  .run(function ($ionicPlatform) {


    $ionicPlatform.ready(function () {     

      // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
      // for form inputs).
      // The reason we default this to hidden is that native apps don't usually show an accessory bar, at
      // least on iOS. It's a dead giveaway that an app is using a Web View. However, it's sometimes
      // useful especially with forms, though we would prefer giving the user a little more room
      // to interact with the app.
      if (window.cordova && window.Keyboard) {
        window.Keyboard.hideKeyboardAccessoryBar(true);
      }

      if (window.StatusBar) {
        // Set the statusbar to use the default style, tweak this to
        // remove the status bar on iOS or change it to use white instead of dark colors.
        StatusBar.styleDefault();
      }
    });
  })

var solarApp = angular.module('starter', ['ionic', 'ui.router', 'chart.js', 'ngCordova']);



solarApp.config(function ($stateProvider, $urlRouterProvider) {

  $stateProvider
    .state('app', {
      url: "/app",
      cache: false,
      abstract: true,
      templateUrl: "templates/menu.html",
      controller: 'appCtrl',
    })
    /* About Us Page*/
    .state('app.home', {
      url: '/home',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/home.html',
          controller: 'appCtrl',
        }
      }
    })

    /* Knowledge list Page*/
    .state('app.knowledge_list', {
      url: '/knowledge_list',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/knowledge_list.html',
          controller: 'appCtrl'
        }
      }
    })

    /* Knowledge list Page*/
    .state('app.knowledge_details', {
      url: '/knowledge_details',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/knowledge_details.html',
          controller: 'appCtrl'
        }
      }
    })



    .state('app.monitor', {
      url: '/monitor',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/monitor.html',
          controller: 'appCtrl'
        }
      }
    })
    .state('app.monitor_night_bg', {
      url: '/monitor_night_bg',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/monitor_night_bg.html',
          controller: 'appCtrl'
        }
      }
    })

    .state('app.annual_graph', {
      url: '/annual_graph',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/annual_graph.html',
          controller: 'appCtrl'
        }
      }
    })

    .state('app.energyoutput_graph', {
      url: '/energyoutput_graph',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/energyoutput_graph.html',
          controller: 'appCtrl'
        }
      }
    })


    .state('app.ticket', {
      url: '/ticket',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/ticket.html',
          controller: 'appCtrl'
        }
      }
    })

    .state('app.terms_conditions', {
      url: '/terms_conditions',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/terms_conditions.html',
          controller: 'appCtrl'
        }
      }
    })



    /* for line graph*/
    /*.state('app.today_power_graph', {
        url: '/today_power_graph',
        cache: false,
        views: {
          'menuContent': {
            templateUrl: 'templates/today_power_graph.html',
            controller: 'appCtrl'
          }
        }
      })*/

    .state('app.annual_graph_test', {
      url: '/annual_graph_test',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/annual_graph_test.html',
          controller: 'appCtrl'
        }
      }
    })

    .state('app.service', {
      url: '/service',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/service.html',
          controller: 'appCtrl'
        }
      }
    })
    /**/

    .state('app.raise_ticket', {
      url: '/raise_ticket',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/raise_ticket.html',
          controller: 'appCtrl'
        }
      }
    })
    .state('app.profile', {
      url: '/profile',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/profile.html',
          controller: 'appCtrl'
        }
      }
    })
    .state('app.changepassword', {
      url: '/change-pwd',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/change-pwd.html',
          controller: 'appCtrl'
        }
      }
    })
    /* forgot password*/
    .state('reset', {
      url: '/reset',
      templateUrl: 'templates/reset.html',
      controller: 'appCtrl'
    })
    /* reset password*/
    .state('reset_forget_pwd', {
      url: '/reset_forget_pwd',
      templateUrl: 'templates/reset_forget_pwd.html',
      controller: 'appCtrl'
    })

    /* Registration*/
    .state('registration', {
      url: '/registration',
      templateUrl: 'templates/registration.html',
      controller: 'appCtrl'
    })


    .state('app.certificate', {
      url: '/certificate',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/certificate.html',
          controller: 'appCtrl'
        }
      }
    })
    .state('app.chat-list', {
      url: '/chat-list',
      cache: false,
      views: {
        'menuContent': {
          templateUrl: 'templates/chat-list.html',
          controller: 'appCtrl'
        }
      }
    })
    .state('channel-partner', {
      url: '/channel-partner',
      templateUrl: 'templates/channel-partner.html',
      controller: 'appCtrl'
    })

    .state('login', {
      url: '/login',
      templateUrl: 'templates/login.html',
      controller: 'appCtrl'
    });
  // alert(window.localStorage.getItem('clientlogin_username'))
  if (window.localStorage.getItem("clientlogin_username") !== null && window.localStorage.getItem("clientlogin_password") !== null) {
    console.log('user undefined...');
    $urlRouterProvider.otherwise("app/home");
    // var today1 = new Date().getHours();
    // console.log(today1);
    // if (today1 >= 19 || today1 <= 5) {

    //   $urlRouterProvider.otherwise("app/monitor_night_bg");
    // } else {
    //   $urlRouterProvider.otherwise("app/monitor");
    // }
   
  }

  else {
    $urlRouterProvider.otherwise("login");   
  }

});


solarApp.controller('appCtrl', function ($scope, $state, $rootScope, $ionicHistory, $timeout, $http, $httpParamSerializerJQLike, $cordovaCamera, $ionicLoading, $window, $ionicPlatform, $ionicPopup) {
  $rootScope.per = "20";

  $rootScope.user_name = window.localStorage.getItem('clientlogin_username');
  $rootScope.user_email = window.localStorage.getItem('$rootScope.user_email');
  $rootScope.userPhoneNo = window.localStorage.getItem('$rootScope.userPhoneNo');
  $rootScope.loginToken = window.localStorage.getItem('clientlogin_token');
  // $scope.clientLoginMonitor = function () {
  //   $scope.clientLogin();
  //  };
  // $scope.getSites = function () { };
  $rootScope.show_monitor = true;
  $rootScope.show_service = true;
  console.log($rootScope.user_name);
  console.log($rootScope.userPhoneNo);
  console.log($rootScope.sites);

  //$rootScope.value=$rootScope.user_name;
  /*$ionicPlatform.registerBackButtonAction(function (event) {
    if($state.current.name=="home"){
      alert("button back");
    }
  }, 100);*/

  //$ionicPlatform.registerBackButtonAction()
  /*$scope.goBackHandler = function()
      {
         // $ionicHistory.goBack();                           //This doesn't work
          window.history.back();                          //This works
          //alert('code to go back called. Did it work?');  //For testing
      }*/

      console.log(window.localStorage['clientlogin_token']);
       $http({
      method: "GET",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/sitedetails",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Auth-Token': window.localStorage['clientlogin_token']
      },
      dataType: "json"

    }).then(function mySuccess(response) {
     
      console.log(response.data);  
      // console.log(window.localStorage.getItem('$rootScope.sites'))    
      // $rootScope.sites=window.localStorage.getItem('$rootScope.sites');    
      // for(i=0;i<$rootScope.sites.length;i++){
      //   $rootScope.site_key=$rootScope.sites[i].site_key;
      // }
      // $rootScope.firstSite=$rootScope.sites[0].site_key;
      // console.log($rootScope.site_key)
      // $rootScope.show_certificate = false;
      // $rootScope.show_menu = false;
      // $rootScope.show_monitor = true;
      // $rootScope.show_service = true;
      // $scope.getSites($rootScope.firstSite);
      // $scope.calculateTodayLastDate();
      // $scope.onlineuserstatus();
      // console.log($rootScope.firstSite);
      
    })

  $ionicPlatform.registerBackButtonAction(function () {

    navigator.app.backHistory();

  }, 100);
  $rootScope.elogin = true;
  $rootScope.loader = function () {
    $ionicLoading.show({
      noBackdrop: true,
      template: '<ion-spinner icon="lines" class="spinner-energized"></ion-spinner> <br/>loading...'
    });
    /*$ionicLoading.show({
      templateUrl:'templates/loading.html'
    });*/
  }

  var clientusername = window.localStorage.getItem('clientlogin_username'); // Pass a key name to get its value.
  var clientpass = window.localStorage.getItem('clientlogin_password'); // Pass a key name to get its value.

  $rootScope.id = clientusername;
  $rootScope.pass = clientpass;

  $scope.isLoggedIn = function () {
    if (window.localStorage.getItem("clientlogin_username") !== undefined && window.localStorage.getItem("clientlogin_password") !== undefined) {
      $state.go('app.home');
      return true;

    } else {
      $state.go('login');
      return false;
    }
  };



  // var localval = window.localStorage.getItem('clientlogin_username');
  //   var localval1 = window.localStorage.getItem('clientlogin_password');
  //   console.log(localval);
  //   console.log(localval1);

  //   if(localval != null && localval1 != null)
  //   {  
  //   $state.go('app.home');   

  //   }

  // $rootScope.colors  = [];
  // $rootScope.labels  = [];
  // $rootScope.data  = [];


  $rootScope.dummyChart = function () {
    var dummyData = $rootScope.dummyChartData;
      // console.log("dummy data:"+ $rootScope.dummyChartData)
    if (dummyData.data != null) {
      console.log("not null");
      $rootScope.showlinechart = true;

      //$rootScope.colors = ['#45b7cd', '#ff6384', '#ff8e72'];
      $rootScope.colors = ['#fac833', '#fac833', '#fac833'];
      /*$rootScope-.colors = [{
              backgroundColor : '#0062ff',
              pointBackgroundColor: '#fac833',
              pointHoverBackgroundColor: '#fac833',
              borderColor: '#fac833',
              pointBorderColor: '#fac833',
              pointHoverBorderColor: '#fac833'
              //fill: false *//* this option hide background-color *//*
}, '#00ADF9', '#FDB45C', '#46BFBD'];*/

      $rootScope.labels = dummyData.data.map(function (x) {
        var d = new Date(x.timestamp * 1000);
        return d.getHours().toString() + ":" + d.getMinutes().toString()
        
      });
      //$rootScope.labels1 = [date];

      $rootScope.data = dummyData.data.map(function (x) { return x.value });
      console.log("dd-"+ $rootScope.data);

      var monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
      ];
      $ionicLoading.hide();
      //var d = new Date();
      //console.log("The current month is " + monthNames[d.getMonth()]);

      var today = new Date();

      //var date = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
      //var date = today.getDate()+'-'+monthNames[(today.getMonth())]+'-'+today.getFullYear();

      var todaydate = today.getDate() + (today.getDate() % 10 == 1 && today.getDate() != 11 ? 'st' : (today.getDate() % 10 == 2 && today.getDate() != 12 ? 'nd' : (today.getDate() % 10 == 3 && today.getDate() != 13 ? 'rd' : 'th')));
      console.log("today_date:"+todaydate)
      //$scope.labels1 = [date];
      $rootScope.showtodaydate = todaydate + " " + monthNames[(today.getMonth())] + "," + today.getFullYear();
      console.log("showtoday:"+ $rootScope.showtodaydate)
      //console.log("today date=="+date);
      //console.log("today date=="+todaydate);
      /* $rootScope.datasetOverride = [
    {
    label: "Line chart",
    borderWidth: 3,
    hoverBackgroundColor: "rgba(255,99,132,0.4)",
    hoverBorderColor: "rgba(255,99,132,1)",
    type: 'line'
}

  ];*/


      $rootScope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];


      // $scope.options = {
      //   tooltips: {
      //     mode: 'index',
      //     xPadding: 25,
      //     yPadding: 25,
      //     intersect: false,
      //   },
      //   "animation": {
      //     "duration": 1,
      //     "onComplete": function () {
      //       var chartInstance = this.chart,
      //         ctx = chartInstance.ctx;

      //       ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
      //       ctx.textAlign = 'center';
      //       ctx.textBaseline = 'bottom';

      //       this.data.datasets.forEach(function (dataset, i) {
      //         var meta = chartInstance.controller.getDatasetMeta(i);
      //         meta.data.forEach(function (bar, index) {
      //           var data = dataset.data[index];
      //           console.log("ddd"+data)
      //           ctx.fillText(data, bar._model.x, bar._model.y - 10);
      //         });
      //       });
      //     }
      //   },
      //   legend: { display: false },

      //   scales: {
      //     yAxes: [
      //       {
      //         id: 'y-axis-1',
      //         type: 'linear',
      //         display: true,
      //         dataPoints: $scope.data,
      //         position: 'left',
      //         ticks: {
      //           beginAtZero: true,
      //         },
      //         gridLines: {
      //           drawOnChartArea: false
      //         }

      //       }
        
      //     ],
      //     xAxes: [{
      //       gridLines: {
      //         drawOnChartArea: false,
      //         display: false,
      //         drawBorder: false,
      //         tickMarkLength: false,
      //       }
      //     }
      //     ],
      //     yAxes: [{
      //       gridLines: {
      //         display: false,
      //         drawBorder: false,
      //         tickMarkLength: false,
      //       }
      //     }]

      //   },
      //   legend: {
      //     display: false
      //   },
      //   plugins: {
      //     datalabels: {
      //       color: 'white',
      //       display: true,
      //       align: 'center',
      //       anchor: 'center'
      //     }
      //   }
      // };
    }
    else {
      // $ionicLoading.hide();
      $rootScope.showlinechart = false;
      $rootScope.showenergygraph = true;
      $ionicLoading.hide();
    }

  }

  //$interval(calculateTodayLastDate, 5000);
  // $scope.calculateTodayLastDate

  //$interval( function(){ $scope.calculateTodayLastDate(); }, 3000);

  /*$scope.labels = ["January", "February", "March", "April", "May", "June", "July"];
      //$scope.series = ['Series A', 'Series B'];
      $scope.data = [
          [0, 59, 80, 81, 0, 55, 40],
          [28, 48, 40, 19, 86, 27, 90]
      ];*/

  /*$scope.goTest=function(){
    $state.go('login');
  }*/

  /* logout Api*/

  $scope.goTest = function () {
    //alert(user_name);
    //alert("customer click");
    //$ionicPopup.hide();
    var logout_data = {};

    var datass = {
      user_id: $rootScope.user_id

    };




    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/logout",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: $httpParamSerializerJQLike(datass),
      dataType: "json"
    }).then(function mySuccess(response) {

      localStorage.clear();
      // alert(JSON.stringify(response.data.message));

      /*var alertPopup = $ionicPopup.alert({

            title: 'Logout',
            template: JSON.stringify(response.data.message),

          });

          alertPopup.then(function(res) {

            console.log('Thank you for not eating my delicious ice cream cone');
          });*/

      $ionicPopup.show({
        title: 'Logout',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          {
            text: 'Thank You',
            onTap: function (e) {
              $state.go('login');;
            }
          },
        ]
      });

      // $state.go('app.certificate');
      //$state.go('login');

    }, function myError(response) {
      //alert(JSON.stringify(response));
      //alert(JSON.stringify(response.data.message));
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });

    })

  };

 

  $scope.goToHome = function () { 
    $rootScope.user_name = window.localStorage.getItem('clientlogin_username');
    console.log($rootScope.user_name);
    console.log(window.localStorage.getItem('clientlogin_token'));
    $scope.clientLoginHome(window.localStorage.getItem('clientlogin_username'), window.localStorage.getItem('clientlogin_password'));
    $state.go('app.home');


    //let browser = window.open('http://www.solarsmiths.com', '_blank', 'location=no');
    //let browser = this.InAppBrowser.create('http://www.solarsmiths.com/');
    //$scope.dummyChart();
    //window.location.reload()
    /*$scope.slideHasChanged(0);*/



  }

  /*$scope.rememberMe1 = function () {
      $cookies.put("emailId", $rootScope.user_email);
  };*/

  $scope.goToWebsite = function (url) {

    //let browser = window.open('http://www.solarsmiths.com', '_blank', 'location=no');
    //window.open("https://www.google.com");
    window.open(url, "_system");
    //$window.open('http://www.solarsmiths.com', '_blank');
    //$scope.url ='http://www.solarsmiths.com/';
    //$window.open('http://www.solarsmiths.com', '_blank');
    //$window.open("//www.solarsmiths.com/");
    //window.open('http://www.solarsmiths.com', '_system');
    //let browser = this.InAppBrowser.create('http://www.solarsmiths.com/');
    //$scope.dummyChart();
    //window.location.reload()
    /*$scope.slideHasChanged(0);*/
    //cordova.InAppBrowser.open('https://www.solarsmiths.com', '_blank', options);


  }

  $scope.getknoledgelist_Data = function () {
    var token = $rootScope.loginToken;
    //$rootScope.success_IsVisible_hideloader =false;
    $rootScope.loader();

    $http({
      method: "GET",

      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/getCategory?categories=3",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Auth-Token': token
      },
      //data: $httpParamSerializerJQLike(datas),
      dataType: "json"
    }).then(function mySuccess(response) {
      //$rootScope.success_IsVisible_hideloader =true;
      $ionicLoading.hide();
      //alert(JSON.stringify(response));
      //$scope.myArray = response.data.cTitle;
      //$rootScope.cTitle =response.data.data;
      $rootScope.myList = response.data.data;
      //$rootScope.cId = response.data.data
      //$rootScope.cId = $rootScope.myList.cId;
      /*$rootScope.cId = response.data.data[0].cId;*/
      //$rootScope.cId = response.data.data[0].cId;
      //JSON.stringify(response)
      //alert("cid=="+JSON.stringify($rootScope.cId));
      //alert("cid=="+JSON.stringify($rootScope.myList.cId));
      //$rootScope.cTitle =response.data.data[0].cTitle;
      /*$rootScope.cDesc= response.data.data;
      $rootScope.cImg= response.data.data[0].cImg;
      $rootScope.cDate= response.data.data;*/

    }, function myError(response) {
      $ionicLoading.hide();
      //alert(JSON.stringify(response));
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });

      //alert(JSON.stringify(response.data.error));

    })

  }

  /* $scope.getknoledge_details_Data=function(){
 var token = $rootScope.loginToken;
 
   $http({
               method: "GET",
 
                url: "http://103.109.6.71/~clientpro/solarsmith/api/users/categoryDetails?cId="+$rootScope.cId, //MTE5Mw==
                     headers: {
                 'Content-Type' : 'application/x-www-form-urlencoded; charset=UTF-8'
                 //'X-Auth-Token' : token
               },
              //data: $httpParamSerializerJQLike(datas),
               dataType: "json"
             }).then(function mySuccess(response) {
 
            $rootScope.cTitle =response.data.data.cTitle;
             $rootScope.cDesc =response.data.data.cDesc;
             $rootScope.cImg =response.data.data.cImg;
             $rootScope.cDate =response.data.data.cDate;
 
              //$state.go('app.knowledge_details');
             }, function myError(response) {
                alert(JSON.stringify(response));
 
                 //alert(JSON.stringify(response.data.error));
 
             })
 
     }*/



  $scope.goToMonitor = function () {
    // $scope.slideHasChanged(0);
    $scope.clientLoginMonitor(window.localStorage.getItem('clientlogin_username'), window.localStorage.getItem('clientlogin_password'));



    var today1 = new Date().getHours();
    console.log(today1);
    if (today1 >= 19 || today1 <= 5) {
      // $state.go('app.monitor');
      $state.go('app.monitor_night_bg');
    } else {

      $state.go('app.monitor');
      // $state.go('app.monitor_night_bg');


    }

    var today = new Date();
    var hours = today.getHours();
    var minutes = today.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'



    var currentTime = hours + ' ' + ampm;
    if (hours == '6' && ampm == 'am') {
      $scope.angle = -60;

    }
    else if (hours == '7' && ampm == 'am') {
      $scope.angle = -50;

    }
    else if (hours == '8' && ampm == 'am') {
      $scope.angle = -40;

    }
    else if (hours == '9' && ampm == 'am') {
      $scope.angle = -30;

    }
    else if (hours == '10' && ampm == 'am') {
      $scope.angle = -20;

    }
    else if (hours == '11' && ampm == 'am') {
      $scope.angle = -10;

    }
    else if (hours == '12' && ampm == 'pm') {
      $scope.angle = 0;

    }
    else if (hours == '1' && ampm == 'pm') {
      $scope.angle = 10;

    }
    else if (hours == '2' && ampm == 'pm') {
      $scope.angle = 20;

    }
    else if (hours == '3' && ampm == 'pm') {
      $scope.angle = 30;

    }
    else if (hours == '4' && ampm == 'pm') {
      $scope.angle = 40;

    }
    else if (hours == '5' && ampm == 'pm') {
      $scope.angle = 50;
      //alert("time"+currentTime);
    }
    else if (hours == '6' && ampm == 'pm') {
      $scope.angle = 60;
      //alert("time"+currentTime);
    }

    /* for night background */

    else if (hours == '7' && ampm == 'pm') {
      $scope.angle = -50;
      //alert("time"+currentTime);
    }
    else if (hours == '8' && ampm == 'pm') {
      $scope.angle = -40;
      //alert("time"+currentTime);
    }
    else if (hours == '9' && ampm == 'pm') {
      $scope.angle = -30;
      //alert("time"+currentTime);
    }
    else if (hours == '10' && ampm == 'pm') {
      $scope.angle = -20;
      //alert("time"+currentTime);
    }
    else if (hours == '11' && ampm == 'pm') {
      $scope.angle = -10;
      //alert("time"+currentTime);
    }
    else if (hours == '12' && ampm == 'am') {
      $scope.angle = 0;
      //alert("time"+currentTime);
    }
    else if (hours == '1' && ampm == 'am') {
      $scope.angle = 10;
      //alert("time"+currentTime);
    }
    else if (hours == '2' && ampm == 'am') {
      $scope.angle = 20;
      //alert("time"+currentTime);
    }
    else if (hours == '3' && ampm == 'am') {
      $scope.angle = 30;
      //alert("time"+currentTime);
    }
    else if (hours == '4' && ampm == 'am') {
      $scope.angle = 40;
      //alert("time"+currentTime);
    }
    else if (hours == '5' && ampm == 'am') {
      $scope.angle = 50;
      //alert("time"+currentTime);
    }



    //var time = today.getHours();

    //$scope.angle = 0;

    //var img =$rootScope.imageId;
    //alert("image"+img);
    //alert("image"+$scope.angle);

  }
  $scope.ticket = function () {
    $state.go('app.ticket');
  }

  $scope.goToWarranty = function () {
    $state.go('app.terms_conditions');
  }
  /* line power graph*/
  /* $scope.goToTodayPower=function(){
       //$scope.loadGraph();

        $state.go('app.today_power_graph');
      $scope.dummyChart();
    } */

  $scope.goToTodayPower = function () {
    //$scope.loadGraph();

    $scope.loadGraph();
    $state.go('app.annual_graph_test');

    //$scope.dummyChart();
  }

  /* Annual graph*/
  $scope.goToAnnualGraph = function () {
    $rootScope.loader();
    var dummyData = $rootScope.annualchartdata;
    if (dummyData.data != null) {

      //alert("dummydata"+JSON.stringify(dummyData));
      // Months array
      var months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

      $rootScope.labels = dummyData.data.map(function (x) {
        var unixtimestamp = x.timestamp * 1000;
        var d = new Date(unixtimestamp);
        var month = months_arr[d.getMonth()];
        return month + d.getFullYear().toString();
        //return $scope.months/*+ ":" + d.getFullYear().toString()*/
      });


      $rootScope.data = dummyData.data.map(function (x) {
        return x.value
       
      }
      );


    };

    /*$scope.loadGraph();*/
    /*$state.go('app.annual_graph');*/
    // $scope.getSitesData_annualgraph(0);
    //$scope.slideHasChanged_annualgraph(0);
    $ionicLoading.hide();
    $state.go('app.annual_graph');
  }

  /* energy output graph for  7 days*/

  $scope.goToEnergyOutputGraph = function () {
    $rootScope.loader();

    //var days; // Days you want to subtract
    //var date = new Date();
    // var date = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    //console.log("date==="+date);
    /*var last = new Date(date.getTime() - (days * 24 * 60 * 60 * 1000));
    console.log("lastdate==="+last);
    var day =last.getDate();
    console.log("day==="+day);
    var month=last.getMonth()+1;
    console.log("month==="+month);
    var year=last.getFullYear();
    console.log("year==="+year);*/

    var dummyData = $rootScope.energychartdata;
    if (dummyData.data != null) {

      //alert("dummydata"+JSON.stringify(dummyData));
      console.log("energydata===" + JSON.stringify(dummyData))
      // Months array
      var months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

      $rootScope.labels = dummyData.data.map(function (x) {


        var unixtimestamp = x.timestamp * 1000;
        var d = new Date(unixtimestamp);
        var date = d.getDate();
        console.log("date===" + date);
        console.log("unixtimestamp===" + unixtimestamp);
        var month = months_arr[d.getMonth()];

        //return month+d.getFullYear().toString();
        return date.toString();

        //return $scope.months/*+ ":" + d.getFullYear().toString()*/
      });


      $rootScope.data = dummyData.data.map(function (x) { return x.value });


    };

    /*$scope.loadGraph();*/
    /*$state.go('app.annual_graph');*/
    // $scope.getSitesData_annualgraph(0);
    //$scope.slideHasChanged_annualgraph(0);
    $ionicLoading.hide();
    $state.go('app.energyoutput_graph');
  }
  $scope.showgraph = function () {
    //$scope.loadGraph();
    //$rootScope.showlinechart =true;

    $rootScope.loader();
    console.log('showgraph clicked...')
    $rootScope.showenergygraph = false;

    //$state.go('app.today_power_graph');
    /*$scope.dummyChart();*/

    var dummyData = $rootScope.dummyChartData;
    //  $rootScope.loader();
    if (dummyData.data != null) {
      $rootScope.showlinechart = true;


      //$rootScope.colors = ['#45b7cd', '#ff6384', '#ff8e72'];
      $rootScope.colors = ['#fac833', '#fac833', '#fac833'];


      $rootScope.labels = dummyData.data.map(function (x) {
        var d = new Date(x.timestamp * 1000);
        return d.getHours().toString() + ":" + d.getMinutes().toString()
      });
      //$rootScope.labels1 = [date];

      $rootScope.data = dummyData.data.map(function (x) { return x.value });

      var monthNames = ["January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
      ];
      $ionicLoading.hide();

      var today = new Date();

      var todaydate = today.getDate() + (today.getDate() % 10 == 1 && today.getDate() != 11 ? 'st' : (today.getDate() % 10 == 2 && today.getDate() != 12 ? 'nd' : (today.getDate() % 10 == 3 && today.getDate() != 13 ? 'rd' : 'th')));
      $rootScope.showtodaydate = todaydate + " " + monthNames[(today.getMonth())] + "," + today.getFullYear();

      $rootScope.datasetOverride = [{ yAxisID: 'y-axis-1' }, { yAxisID: 'y-axis-2' }];

      var ctx = document.getElementById("bar");
      $scope.options = {
        tooltips: {
          mode: 'index',
          xPadding: 25,
          yPadding: 25,
          intersect: false,
        },
        title: {
          display: false,
          fontColor: 'black'
        },
        "animation": {
          "duration": 1,
          "onComplete": function () {
            var chartInstance = this.chart,
              ctx = chartInstance.ctx;

            ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
            ctx.textAlign = 'center';
            ctx.textBaseline = 'bottom';

            this.data.datasets.forEach(function (dataset, i) {
              var meta = chartInstance.controller.getDatasetMeta(i);
              meta.data.forEach(function (bar, index) {
                // var data = dataset.data[index];
                // ctx.fillText(data, bar._model.x, bar._model.y - 0);
              });
            });
          }
        },
        legend: { display: false },
        scales: {
          yAxes: [
            {
              id: 'y-axis-1',
              type: 'linear',
              display: true,
              color:'white',
              dataPoints: $scope.data,
              position: 'left',
              ticks: {
                beginAtZero: true,
                // fontColor: "red",
              },
              gridLines: {
                drawOnChartArea: false,

              }

            }

          ],
          xAxes: [{
            gridLines: {
              drawOnChartArea: false,
              display: false,
              drawBorder: false,
              tickMarkLength: false,
            }
          }
          ],
          yAxes: [{
            gridLines: {
              display: false,
              drawBorder: false,
              tickMarkLength: false,
            }
          }]

        },
        legend: {
          display: false
        },
        plugins: {
          datalabels: {
            color: 'white',
            display: true,
            align: 'center',
            anchor: 'center'
          }
        }
      };
    }
    else {
      // $ionicLoading.hide();
      $rootScope.showlinechart = false;
      $rootScope.showenergygraph = true;
      $ionicLoading.hide();
    }


  }


  $scope.goToProfile = function () {
    $state.go('app.profile');
    $scope.getProfileData();
  }

  $scope.goToKnowledgecenter = function () {

    //$scope.getknoledgelist_Data();

    var token = $rootScope.loginToken;
    //$rootScope.success_IsVisible_hideloader =false;
    $rootScope.loader();

    $http({
      method: "GET",

      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/getCategory?categories=3",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Auth-Token': token
      },
      //data: $httpParamSerializerJQLike(datas),
      dataType: "json"
    }).then(function mySuccess(response) {
      //$rootScope.success_IsVisible_hideloader =true;
      $ionicLoading.hide();

      $rootScope.myList = response.data.data;
      $state.go('app.knowledge_list');

    }, function myError(response) {
      $ionicLoading.hide();
      //alert(JSON.stringify(response));
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });

      //alert(JSON.stringify(response.data.error));

    })


  }

  $scope.goToknowledgedetails = function (cId) {
    //alert("CID"+cId);
    //$scope.getknoledge_details_Data();
    //$state.go('app.knowledge_details');
    //$rootScope.success_IsVisible_hideloader =false;
    $rootScope.loader();

    $http({
      method: "GET",

      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/categoryDetails?cId=" + cId, //MTE5Mw==
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
        //'X-Auth-Token' : token
      },
      //data: $httpParamSerializerJQLike(datas),
      dataType: "json"
    }).then(function mySuccess(response) {
      $ionicLoading.hide();
      //$rootScope.success_IsVisible_hideloader =true;
      $state.go('app.knowledge_details');
      //alert(JSON.stringify(response));
      //$scope.myArray = response.data.cTitle;
      //$rootScope.cTitle =response.data.data;
      //$rootScope.myList =response.data.data;
      $rootScope.cTitle = response.data.data.cTitle;
      $rootScope.cDesc = response.data.data.cDesc;
      $rootScope.cImg = response.data.data.cImg;
      $rootScope.cDate = response.data.data.cDate;
      /*$rootScope.cDesc= response.data.data;
      $rootScope.cImg= response.data.data;
      $rootScope.cDate= response.data.data;*/
      //$state.go('app.knowledge_details');
    }, function myError(response) {
      $ionicLoading.hide();
      //alert(JSON.stringify(response));
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });


      //alert(JSON.stringify(response.data.error));

    })
  }




  $scope.goToChangePassword = function () {
    $state.go('app.changepassword');
  }
  $scope.certificate = function () {
    $state.go('app.certificate');
  }
  $scope.goToService = function () {
    $state.go('app.service');
  }

  $scope.chatList = function () {
    $state.go('app.chat-list');
  }
  $scope.channelPartner = function () {
    $state.go('channel-partner');
    //$scope.channelPartnerLogin(user_name,password);

  }
  $scope.resetPass = function () {
    $state.go('reset');

  }
  $scope.registration = function () {
    $state.go('registration');

  }
  $scope.resetPassforget = function () {
    $state.go('reset_forget_pwd');

  }

  $scope.clientLogin = function (Cid, Cpass) {
    
    $rootScope.loader();


    var login_data = {};
    var datas = {
      user_name: Cid,
      password: Cpass
    };


    // var storage = window.localStorage;

    // window.localStorage.setItem('clientlogin_username', Cid); // Pass a key name and its value to add or update that key.
    //window.localStorage.setItem('clientlogin_password', Cpass); // Pass a key name and its value to add or update that key.
    //storage.removeItem(key)
    /* var clientusername = storage.getItem('clientlogin_username'); // Pass a key name to get its value.
     var clientpass = storage.getItem('clientlogin_password'); // Pass a key name to get its value.
     alert("username"+clientusername);
     alert("password"+clientpass);*/

    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/login",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: $httpParamSerializerJQLike(datas),
      dataType: "json"
    }).then(function mySuccess(response) {
      // $scope.getDeviceToken();
    
      $ionicLoading.hide();
      //$state.go('app.monitor');
      // $scope.getDeviceToken();
      var today = new Date();
      var hours = today.getHours();
      var minutes = today.getMinutes();
      var ampm = hours >= 12 ? 'pm' : 'am';
      hours = hours % 12;
      hours = hours ? hours : 12; // the hour '0' should be '12'
  
  
  
      var currentTime = hours + ' ' + ampm;
      if (hours == '6' && ampm == 'am') {
        $scope.angle = -60;
  
      }
      else if (hours == '7' && ampm == 'am') {
        $scope.angle = -50;
  
      }
      else if (hours == '8' && ampm == 'am') {
        $scope.angle = -40;
  
      }
      else if (hours == '9' && ampm == 'am') {
        $scope.angle = -30;
  
      }
      else if (hours == '10' && ampm == 'am') {
        $scope.angle = -20;
  
      }
      else if (hours == '11' && ampm == 'am') {
        $scope.angle = -10;
  
      }
      else if (hours == '12' && ampm == 'pm') {
        $scope.angle = 0;
  
      }
      else if (hours == '1' && ampm == 'pm') {
        $scope.angle = 10;
  
      }
      else if (hours == '2' && ampm == 'pm') {
        $scope.angle = 20;
  
      }
      else if (hours == '3' && ampm == 'pm') {
        $scope.angle = 30;
  
      }
      else if (hours == '4' && ampm == 'pm') {
        $scope.angle = 40;
  
      }
      else if (hours == '5' && ampm == 'pm') {
        $scope.angle = 50;
        //alert("time"+currentTime);
      }
      else if (hours == '6' && ampm == 'pm') {
        $scope.angle = 60;
        //alert("time"+currentTime);
      }
  
      /* for night background */
  
      else if (hours == '7' && ampm == 'pm') {
        $scope.angle = -50;
        //alert("time"+currentTime);
      }
      else if (hours == '8' && ampm == 'pm') {
        $scope.angle = -40;
        //alert("time"+currentTime);
      }
      else if (hours == '9' && ampm == 'pm') {
        $scope.angle = -30;
        //alert("time"+currentTime);
      }
      else if (hours == '10' && ampm == 'pm') {
        $scope.angle = -20;
        //alert("time"+currentTime);
      }
      else if (hours == '11' && ampm == 'pm') {
        $scope.angle = -10;
        //alert("time"+currentTime);
      }
      else if (hours == '12' && ampm == 'am') {
        $scope.angle = 0;
        //alert("time"+currentTime);
      }
      else if (hours == '1' && ampm == 'am') {
        $scope.angle = 10;
        //alert("time"+currentTime);
      }
      else if (hours == '2' && ampm == 'am') {
        $scope.angle = 20;
        //alert("time"+currentTime);
      }
      else if (hours == '3' && ampm == 'am') {
        $scope.angle = 30;
        //alert("time"+currentTime);
      }
      else if (hours == '4' && ampm == 'am') {
        $scope.angle = 40;
        //alert("time"+currentTime);
      }
      else if (hours == '5' && ampm == 'am') {
        $scope.angle = 50;
        //alert("time"+currentTime);
      }
      var today1 = new Date().getHours();
      console.log(today1);
      if (today1 >= 19 || today1 <= 5) {
        //  $state.go('app.monitor');
        $state.go('app.monitor_night_bg');
      } else {
        // $state.go('app.monitor_night_bg');
        $state.go('app.monitor'); 
      }
      
     
  
      // $state.go('app.monitor');
      $rootScope.show_certificate = false;
      $rootScope.show_menu = false;
      $rootScope.show_monitor = true;
      $rootScope.show_service = true;

      window.localStorage.setItem('clientlogin_username', Cid); // Pass a key name and its value to add or update that key.
      window.localStorage.setItem('clientlogin_password', Cpass);
      //window.localStorage.setItem('clientlogin_username',Cid);
      // window.localStorage.setItem('clientlogin_password',Cpass);
      //alert(JSON.stringify(response.data.message));

      /* var hours = new Date().getHours()
       alert("hours"+hours);
       var isDayTime = hours > 6 && hours < 20
       alert("daytime"+isDayTime);
       if(isDayTime){
       $rootScope.day_IsVisible=true;
       $rootScope.night_IsVisible=false;
       alert("day_IsVisible"+$rootScope.day_IsVisible);
       alert("night_IsVisible"+$rootScope.night_IsVisible);
 
       }
       else{
       $rootScope.day_IsVisible=false;
        $rootScope.night_IsVisible=true;
       }*/

      // $rootScope.show_menu = true;
      if (response.data.status == false) {

        $rootScope.elogin = false;

      }
      /*if(response.data.user_type==4){
      alert(response.data.user_type);
      *//*$rootScope.testData=response.data;
           $rootScope.loginData=$rootScope.testData.login;
           $rootScope.sites=$rootScope.loginData.sites;
           $scope.firstSite=$rootScope.sites[0].site_key;
           $rootScope.loginToken=$rootScope.loginData.token;*//*
// $state.go('app.home');
$state.go('app.certificate');
}*/
      else {

        $rootScope.testData = response.data;
        $rootScope.loginData = $rootScope.testData.login;
        $rootScope.user_id = $rootScope.loginData.user_id; // get user id
        $rootScope.user_name = $rootScope.loginData.user_name; // get user name
        $rootScope.sites = $rootScope.loginData.sites;
        window.localStorage.setItem('$rootScope.sites', JSON.stringify($rootScope.loginData.sites))
        console.log($rootScope.sites);
        $rootScope.user_email = $rootScope.loginData.user_email;
        $rootScope.userPhoneNo = $rootScope.loginData.user_phone; // for showing phone number in menu // 28-08-20
        window.localStorage.setItem('$rootScope.user_email', $rootScope.loginData.user_email);
        window.localStorage.setItem('$rootScope.userPhoneNo', $rootScope.loginData.user_phone);
        //$rootScope.user_login_id=$rootScope.loginData.user_login_id;

        for (i = 0; i < $rootScope.sites.length; i++) {
          $rootScope.site_key = $rootScope.sites[i].site_key;
          //alert("site"+$rootScope.Site);

        }
        $rootScope.status = response.data.status;
        $rootScope.firstSite = $rootScope.sites[0].site_key;
        $rootScope.loginToken = $rootScope.loginData.token;
        $rootScope.user_certificate = $rootScope.loginData.user_certificate;
        window.localStorage.setItem('$rootScope.user_certificate', $rootScope.loginData.user_certificate);
        window.localStorage.setItem('$rootScope.firstSite', $rootScope.sites[0].site_key);
        window.localStorage.setItem('$rootScope.userPhoneNo', $rootScope.loginData.user_phone);
        $scope.getSites($scope.firstSite);
        $scope.calculateTodayLastDate();
        window.localStorage.setItem('clientlogin_token', $rootScope.loginData.token);
        $scope.onlineuserstatus();
        // alert(token1);   
        // alert($rootScope.user_id);
        // alert(device.uuid);
        // alert(device.platform)
        FCMPlugin.subscribeToTopic('all');
        FCMPlugin.getToken(
          function (token1) {
            $rootScope.fcmToken = token1;
            $rootScope.fcmToken1= $rootScope.fcmToken
            console.log(token1);
            // alert(token1);
            // alert($rootScope.user_id);
            // alert(device.uuid);
            // alert(device.platform)
            var datas_fcm = {
              user_id:  $rootScope.user_id,
              fcm_token: token1,
              fcm_device_id: device.uuid,
              fcm_device_type:device.platform,
            }
            $http({
              method: "POST",
              url: "http://103.109.6.71/~clientpro/solarsmith/api/users/fcm_details",
              headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
              },
              data: $httpParamSerializerJQLike(datas_fcm),
              dataType: "json"
            }).then(function mySuccess(response){
              //  alert(JSON.stringify(response.data))
              console(JSON.stringify(response.data.success))
            },function myError(response){
            })            
          },
          function (err) {           
            console.log('error retrieving token: ' + err);
          }
        );
        FCMPlugin.onTokenRefresh(function (rtoken) {       
          $rootScope.refreshToken = rtoken;
          console.log('token' + token);
        });
        FCMPlugin.onNotification(function (data) {
          if (data.wasTapped) {
          }
          else {
          }
        }, function (msg) {
          console.log('onNotification callback successfully registered: ' + msg);
        },
          function (err) {
            console.log('Error registering onNotification callback: ' + err);
          })  

      }
    }, function myError(response) {
      $ionicPopup.show({
        title: ' Customer Login',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          {
            text: 'Thank You',

            onTap: function (e) {
              $state.go('login');;
            }
          },

        ]
      });
      $rootScope.elogin = false;
      $ionicLoading.hide();



    })

  };

  $scope.clientLoginHome = function (Cid, Cpass) {

    $rootScope.loader();


    var login_data = {};
    var datas = {
      user_name: Cid,
      password: Cpass
    };




    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/login",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: $httpParamSerializerJQLike(datas),
      dataType: "json"
    }).then(function mySuccess(response) {

      $ionicLoading.hide();

      // var today1 = new Date().getHours();
      // console.log(today1);
      //     if (today1>=19 || today1 <= 5) {

      //       $state.go('app.monitor_night_bg');
      //    } else {

      //        $state.go('app.monitor');


      //    }
      $state.go('app.home');
      $rootScope.show_certificate = false;
      $rootScope.show_menu = false;
      $rootScope.show_monitor = true;
      $rootScope.show_service = true;

      window.localStorage.setItem('clientlogin_username', Cid); // Pass a key name and its value to add or update that key.
      window.localStorage.setItem('clientlogin_password', Cpass);
      //window.localStorage.setItem('clientlogin_username',Cid);
      // window.localStorage.setItem('clientlogin_password',Cpass);
      //alert(JSON.stringify(response.data.message));

      /* var hours = new Date().getHours()
       alert("hours"+hours);
       var isDayTime = hours > 6 && hours < 20
       alert("daytime"+isDayTime);
       if(isDayTime){
       $rootScope.day_IsVisible=true;
       $rootScope.night_IsVisible=false;
       alert("day_IsVisible"+$rootScope.day_IsVisible);
       alert("night_IsVisible"+$rootScope.night_IsVisible);
 
       }
       else{
       $rootScope.day_IsVisible=false;
        $rootScope.night_IsVisible=true;
       }*/

      // $rootScope.show_menu = true;
      if (response.data.status == false) {

        $rootScope.elogin = false;

      }
      /*if(response.data.user_type==4){
      alert(response.data.user_type);
      *//*$rootScope.testData=response.data;
           $rootScope.loginData=$rootScope.testData.login;
           $rootScope.sites=$rootScope.loginData.sites;
           $scope.firstSite=$rootScope.sites[0].site_key;
           $rootScope.loginToken=$rootScope.loginData.token;*//*
// $state.go('app.home');
$state.go('app.certificate');
}*/
      else {

        $rootScope.testData = response.data;
        $rootScope.loginData = $rootScope.testData.login;
        $rootScope.user_id = $rootScope.loginData.user_id; // get user id
        $rootScope.user_name = $rootScope.loginData.user_name; // get user name
        $rootScope.sites = $rootScope.loginData.sites;
        window.localStorage.setItem('$rootScope.sites', JSON.stringify($rootScope.loginData.sites))
        console.log($rootScope.sites);
        $rootScope.user_email = $rootScope.loginData.user_email;
        $rootScope.userPhoneNo = $rootScope.loginData.user_phone; // for showing phone number in menu // 28-08-20
        window.localStorage.setItem('$rootScope.user_email', $rootScope.loginData.user_email);
        window.localStorage.setItem('$rootScope.userPhoneNo', $rootScope.loginData.user_phone);
        //$rootScope.user_login_id=$rootScope.loginData.user_login_id;

        for (i = 0; i < $rootScope.sites.length; i++) {
          $rootScope.site_key = $rootScope.sites[i].site_key;
          //alert("site"+$rootScope.Site);

        }
        $rootScope.status = response.data.status;
        $rootScope.firstSite = $rootScope.sites[0].site_key;
        $rootScope.loginToken = $rootScope.loginData.token;
        $rootScope.user_certificate = $rootScope.loginData.user_certificate;
        $scope.getSites($scope.firstSite);
        $scope.calculateTodayLastDate();
        //$scope.calculateCurrentLastFiveMonth();
        window.localStorage.setItem('clientlogin_token', $rootScope.loginData.token);

        $scope.onlineuserstatus();
        //$rootScope.value=$rootScope.user_name;

      }
    }, function myError(response) {
      //alert(JSON.stringify(response.data.message));
      $ionicPopup.show({
        title: ' Customer Login',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          {
            text: 'Thank You',

            onTap: function (e) {
              $state.go('login');;
            }
          },

        ]
      });
      $rootScope.elogin = false;
      $ionicLoading.hide();



    })


  };

  $scope.clientLoginMonitor = function () {

    $rootScope.user_name = window.localStorage.getItem('clientlogin_username');
    console.log($rootScope.user_name);

    console.log(window.localStorage.getItem('clientlogin_token'));
    $scope.clientLogin(window.localStorage.getItem('clientlogin_username'), window.localStorage.getItem('clientlogin_password'));
    $state.go('app.home');


  };

  //$scope.channelPartnerLogin();

  /* added by rajnish for channel partner login*/

  $scope.channelPartnerLogin = function (id, pass) {
    //alert(user_name);
    var login_data = {};
    var datass = {
      user_name: id,
      password: pass
    };
    //alert(JSON.stringify(datass));

    /*if(id==undefined){
     alert("Please Enter User Id");
    }
    else if(pass==undefined){
    alert("Please Enter Password");
    }*/
    //else{

    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/login",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: $httpParamSerializerJQLike(datass),
      dataType: "json"
    }).then(function mySuccess(response) {
      // alert(JSON.stringify(response));
      //$state.go('channel-partner');
      $state.go('app.certificate');

      //this.menuContent.enable(false, 'Home');
      //this.appCtrl.enable (false, 'Home');
      $rootScope.show_menu = true;
      $rootScope.show_certificate = true;
      $rootScope.show_monitor = false;
      $rootScope.show_service = false;


      if (response.data.status == false) {

        $rootScope.elogin = false;

      } else {
        $rootScope.testData = response.data;
        $rootScope.loginData = $rootScope.testData.login;
        //$rootScope.sites=$rootScope.loginData.sites;
        //$scope.firstSite=$rootScope.sites[0].site_key;
        $rootScope.loginToken = $rootScope.loginData.token;
        $rootScope.user_certificate = $rootScope.loginData.user_certificate;

        $rootScope.user_name = $rootScope.loginData.user_name; // get user name
        //$scope.getSites($scope.firstSite);
        // $scope.calculateTodayLastDate();




      }
    }, function myError(response) {
      //alert(JSON.stringify(response.data.message));
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
      /*$rootScope.elogin=false;*/



    })
    //}

  };


  $scope.calculateTodayLastDate = function () {

    var today = new Date();
    var dd = String(today.getDate()).padStart(2, '0');
    //var api_dd = String(today.getDate() + 1).padStart(2, '0');
    var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
    var yyyy = today.getFullYear();

    var hh = String(today.getHours()).padStart(2, '0');
    var min = String(today.getMinutes()).padStart(2, '0');
    $rootScope.today_time = hh + ':' + min;

    var ts = $rootScope.today_time;
    var H = +ts.substr(0, 2);
    var h = (H % 12) || 12;
    h = (h < 10) ? ("0" + h) : h;  // leading 0 at the left for 1 digit hours
    $rootScope.ampm = H < 12 ? "AM" : "PM";
    $rootScope.today_time = h + ':' + min;

    // console.log($rootScope.today_time+'...'+ts);

    $rootScope.today_date = dd + '-' + mm + '-' + yyyy;
    //$rootScope.api_today_date = api_dd+ '-' + mm + '-' + yyyy;

    $rootScope.today_date_timestamp = today.getTime() / 1000;
    //alert($rootScope.today_date_timestamp);
    console.log("todate===" + $rootScope.today_date_timestamp);

    //var last = new Date(today.getTime() - (4 * 24 * 60 * 60 * 1000));
    var last = new Date(today.getTime() - (6 * 24 * 60 * 60 * 1000));
    //  alert('here.......');
    var last_dd = String(last.getDate()).padStart(2, '0');
    var last_mm = String(last.getMonth() + 1).padStart(2, '0'); //January is 0!
    var last_yyyy = last.getFullYear();

    $rootScope.last_date = last_dd + '-' + last_mm + '-' + last_yyyy;
    $rootScope.last_date_timestamp = last.getTime() / 1000;
    //alert($rootScope.last_date_timestamp);
    console.log("fromdate===" + $rootScope.last_date_timestamp);

    /* for power*/

    //var from_date_powerdatetime = new Date(today.getTime());
    //var todayy = from_date_powerdatetime.startOfDay();
    var from_date_powerdatetime = new Date();
    if (from_date_powerdatetime.getHours() < 24/*12*/) {
      from_date_powerdatetime.setHours(0, 0, 0, 0); // previous midnight day
      // alert("previous midnight day"+from_date_powerdatetime);
    } /*else {
          from_date_powerdatetime.setHours(24,0,0,0); // next midnight day
          alert("next midnight day"+from_date_powerdatetime);
          }*/
    //alert("todayy"+todayy);
    $rootScope.from_today_date_timestamp_power = from_date_powerdatetime.getTime() / 1000;
    //alert("from todaydate"+$rootScope.from_today_date_timestamp_power);
    //  alert('today...'+$rootScope.today_date+'....last...'+$rootScope.last_date);
    //alert("today"+$rootScope.from_today_date_timestamp_power);
    console.log("todaydatepower1===" + $rootScope.from_today_date_timestamp_power);
    console.log("todaydatepower2===" + $rootScope.today_date_timestamp);

  };
  $scope.convertStrToInt = function (val) {
    return parseInt(val);
  };


  $scope.loadGraph = function () {
    var dummyData = $rootScope.annualchartdata;
    if (dummyData.data != null) {
      $ionicLoading.hide();
      //alert("dummydata"+JSON.stringify(dummyData));
      // Months array
      var months_arr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

      $rootScope.labels = dummyData.data.map(function (x) {


        var unixtimestamp = x.timestamp * 1000;
        var d = new Date(unixtimestamp);
        var month = months_arr[d.getMonth()];

        return month + d.getFullYear().toString();
        //return $scope.months/*+ ":" + d.getFullYear().toString()*/
      });


      $rootScope.data = dummyData.data.map(function (x) { return x.value });

    };
  }


  $scope.uploadImage = function () {

    var options = {
      quality: 75,
      destinationType: Camera.DestinationType.DATA_URL,
      sourceType: Camera.PictureSourceType.CAMERA,
      allowEdit: true,
      encodingType: Camera.EncodingType.JPEG,
      targetWidth: 300,
      targetHeight: 300,
      popoverOptions: CameraPopoverOptions,
      saveToPhotoAlbum: false
    };

    $cordovaCamera.getPicture(options).then(function (imageData) {
      $rootScope.profile_image = "data:image/jpeg;base64," + imageData;

      // $rootScope.newURI = "data:image/jpeg;base64," + imageData;
    }, function (err) {
      // An error occured. Show a message to the user
      //alert("profileimg"+err);
    });

    /*  navigator.camera.getPicture( $scope.onSuccess,  $scope.onFail, { quality: 25,
     destinationType: Camera.DestinationType.DATA_URL
 });*/
    //alert('hi...');
  };

  /*$scope.getBase64Image=function(img) {
var canvas = document.createElement("canvas");
canvas.width = img.width;
canvas.height = img.height;
var ctx = canvas.getContext("2d");
ctx.drawImage(img, 0, 0);
var dataURL = canvas.toDataURL("image/png");
return dataURL.replace(/^data:image\/(png|jpg);base64,/, "");
};*/

  $scope.onSuccess = function (imageData) {
    // var image = document.getElementById('myImage');
    var image = document.getElementById('myImage');
    image.src = "data:image/jpeg;base64," + imageData;
    $rootScope.profile_image = "data:image/jpeg;base64," + imageData;
    $scope.profile_image = "data:image/jpeg;base64," + imageData;
    //alert("profileimg"+$rootScope.profile_image);
    //alert("profileimg"+imageData);
  };

  $scope.onFail = function (message) {
    alert('Failed because: ' + message);
  };

  $scope.uploadCompanyImage = function () {
    var options = {
      quality: 75,
      destinationType: Camera.DestinationType.DATA_URL,
      sourceType: Camera.PictureSourceType.CAMERA,
      allowEdit: true,
      encodingType: Camera.EncodingType.JPEG,
      targetWidth: 300,
      targetHeight: 300,
      popoverOptions: CameraPopoverOptions,
      saveToPhotoAlbum: false
    };

    $cordovaCamera.getPicture(options).then(function (imageData) {
      $rootScope.company_logo = "data:image/jpeg;base64," + imageData;
      // $rootScope.newURI = "data:image/jpeg;base64," + imageData;
    }, function (err) {
      // An error occured. Show a message to the user
    });
    /*  navigator.camera.getPicture($scope.onSuccess1,  $scope.onFail1, { quality: 25,
     destinationType: Camera.DestinationType.DATA_URL
 });*/
    //alert('hi...');
  };


  $scope.onSuccess1 = function (imageData) {
    // var image = document.getElementById('myImage');
    $rootScope.company_logo = "data:image/jpeg;base64," + imageData;
    $scope.company_logo = "data:image/jpeg;base64," + imageData;
  };

  $scope.onFail1 = function (message) {
    alert('Failed because: ' + message);
  };
  /*   $rootScope.uploadImage = function () {
     alert('hi in rootscope...');
    };*/
  //  function openFilePicker(selection) {

  $rootScope.uploadGalleryImage = function (selection) {


    //alert('cordova file...'+cordova.file);
    //console.log('cordova file...'+cordova.file);

    var srcType = Camera.PictureSourceType.SAVEDPHOTOALBUM;
    var options = setOptions(srcType);
    //var func = createNewFileEntry;

    navigator.camera.getPicture(function cameraSuccess(imageUri) {

      $rootScope.company_logo = imageUri;
      //console.log("got file: " + imageUri);
      // createNewFileEntry(imageUri);
      // Do something

    }, function cameraError(error) {
      console.debug("Unable to obtain picture: " + error, "app");

    }, options);
  };

  createNewFileEntry = function (imgUri) {

    /* window.resolveLocalFileSystemURL(imgUri, function success(fileEntry) {
               console.log("got file: " + fileEntry.fullPath);
               console.log('cdvfile URI: ' + fileEntry.toInternalURL());
                $rootScope.company_logo = fileEntry.toInternalURL();
              // $('#imgPreview').attr("src", fileEntry.toInternalURL());
           });*/

    window.resolveLocalFileSystemURL(imgUri, function success(fileEntry) {

      // Do something with the FileEntry object, like write to it, upload it, etc.
      // writeFile(fileEntry, imgUri);
      //console.log("got file: " + fileEntry.fullPath);
      alert('error...' + JSON.stringify(fileEntry));
      $rootScope.company_logo = fileEntry.nativeURL;
      // displayFileData(fileEntry.nativeURL, "Native URL");

    }, function () {
      // If don't get the FileEntry (which may happen when testing
      // on some emulators), copy to a new FileEntry.
      alert('here...');
      createNewFileEntry(imgUri);
    });

    /* window.resolveLocalFileSystemURL(imgUri, function success(dirEntry) {
 
         // JPEG file
         dirEntry.getFile("tempFile.jpeg", { create: true, exclusive: false }, function (fileEntry) {
 
             // Do something with it, like write to it, upload it, etc.
             // writeFile(fileEntry, imgUri);
              $rootScope.company_logo = fileEntry.fullPath;
             console.log("got file in createNewFileEntry: " + fileEntry.fullPath);
             // displayFileData(fileEntry.fullPath, "File copied to");
 
         }, onErrorCreateFile);
 
     }, function(error){
    alert('error...'+JSON.stringify(error));
     });*/
  };
  function createNewFileEntry(imgUri) {
    window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function success(dirEntry) {

      // JPEG file
      dirEntry.getFile("tempFile.jpeg", { create: true, exclusive: false }, function (fileEntry) {

        // Do something with it, like write to it, upload it, etc.
        // writeFile(fileEntry, imgUri);
        //console.log("got file: " + fileEntry.fullPath);
        // displayFileData(fileEntry.fullPath, "File copied to");

      }, function (error) {
        alert('error...' + JSON.stringify(error));
      });

    }, function (error) {
      alert('error...' + JSON.stringify(error));
    });
  };

  setOptions = function (srcType) {
    var options = {
      // Some common settings are 20, 50, and 100
      quality: 50,
      destinationType: Camera.DestinationType.FILE_URI,
      // In this app, dynamically set the picture source, Camera or photo gallery
      sourceType: srcType,
      encodingType: Camera.EncodingType.JPEG,
      mediaType: Camera.MediaType.PICTURE,
      allowEdit: true,
      correctOrientation: true
    }
    return options;
  };

  $scope.submitProfileData = function (profile_image, userName, company_logo, companyName, userDescription, userPhoneNo, trackSo) {

    var token = $rootScope.loginToken;

    //  alert('hiii...'+profile_image+'\n'+userName+'\n'+company_logo+'\n'+companyName+'\n'+userDescription+'\n'+userPhoneNo);
    //console.log('hiii...'+profile_image+'\n'+userName+'\n'+company_logo+'\n'+companyName+'\n'+userDescription+'\n'+userPhoneNo);

    /*  var base64 = $scope.getBase64Image(document.getElementById("myImage"));
      console.log('base64..'+base64);*/
    //  alert('userType...'+$rootScope.userType);
    if ($rootScope.userType == 2) {
      var datas = {
        user_phone: userPhoneNo,
        user_name: userName,
        user_description: userDescription,
        /*image: profile_image,*/
        image: profile_image,
        decoded_password: trackSo
      };
      //alert("imges=="+JSON.stringify(datas));
      //alert("imges=="+$rootScope.profile_image);
      console.log("imges==" + JSON.stringify(datas));

    }
    else if ($rootScope.userType == 4) {
      var datas = {
        user_phone: userPhoneNo,
        user_name: userName,
        user_company_name: companyName,
        logo: company_logo,
        user_description: userDescription,
        image: profile_image
      };
    }
    else {

      var datas = {
        user_phone: userPhoneNo,
        user_name: userName,
        user_company_name: companyName,
        logo: company_logo,
        user_description: userDescription,
        image: profile_image
      };

    }

    //console.log('json..'+JSON.stringify(datas));
    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/profileupdate",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Auth-Token': token
      },
      data: $httpParamSerializerJQLike(datas),
      dataType: "json"
    }).then(function mySuccess(response) {
      //  alert(JSON.stringify(response));
      if (response.data.error == undefined) {

        //alert("Your profile has been updated.");

        /*var alertPopup = $ionicPopup.alert({

                                title: 'Profile Update',
                                template: 'Your profile has been updated.',

                              });

                              alertPopup.then(function(res) {

                                console.log('Thank you for not eating my delicious ice cream cone');
                              });*/

        $ionicPopup.show({
          title: 'Profile Update',
          cssClass: 'popup-container',
          template: 'Your profile has been updated.',
          scope: $rootScope,
          buttons: [
            {
              text: 'Thank You',
              onTap: function (e) {
                $scope.goToHome();
              }
            },
          ]
        });


        /* $scope.goToHome();*/
        // $rootScope.elogin=false;

      } else {
        /*alert("Failure..."+JSON.stringify(response.data.error));*/
        $ionicPopup.show({
          title: 'Alert ',
          cssClass: 'popup-container',
          //template: JSON.stringify(response.data.error.user_phone),
          template: JSON.stringify(response.data.error),
          scope: $rootScope,
          buttons: [
            { text: 'Thank You' },
          ]
        });

      }
      /*if(response.data.status==false){

        $rootScope.elogin=false;

      }else{
      $rootScope.testData=response.data;
      $rootScope.loginData=$rootScope.testData.login;
      $rootScope.sites=$rootScope.loginData.sites;
      $scope.firstSite=$rootScope.sites[0].site_key;
      $rootScope.loginToken=$rootScope.loginData.token;
      $scope.getSites($scope.firstSite);
       $scope.calculateTodayLastDate();


    }*/
    }, function myError(response) {
      /* alert(JSON.stringify(response));*/
      $ionicPopup.show({
        title: 'Alert ',
        cssClass: 'popup-container',
        template: JSON.stringify(response),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },
        ]
      });
      //    $rootScope.elogin=false;



    })
  };

  $scope.getProfileData = function () {

    var token = $rootScope.loginToken;

    //alert('hiii in getProfile...'+token);


    $http({
      method: "GET",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/profile",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Auth-Token': token
      },
      dataType: "json"
    }).then(function mySuccess(response) {
      //   alert('success..'+JSON.stringify(response));
      //console.log('get profile success..'+JSON.stringify(response));
      $rootScope.profile_image = response.data.user_image;
      $rootScope.company_logo = response.data.user_logo;
      $rootScope.userName = response.data.user_name;
      $rootScope.companyName = response.data.user_company_name;
      $rootScope.userDescription = response.data.user_description;
      $rootScope.userPhoneNo = response.data.user_phone;
      $rootScope.userType = response.data.user_type;


      //   alert($rootScope.userType+'...'+response.data.user_type);
      if (response.data.user_type == 2) {
        // alert('inside if');
        $rootScope.trackSo = response.data.decoded_password;
        $scope.companylogo_IsVisible = false;
        $scope.trackso_IsVisible = true;
      }
      else if (response.data.user_type == 4) {
        // alert('inside if');
        $rootScope.trackSo = response.data.decoded_password;
        $scope.companylogo_IsVisible = true;
        $scope.trackso_IsVisible = false;
      }
      else {
        // alert('inside else');
        $scope.companylogo_IsVisible = true;
        $scope.trackso_IsVisible = false;
      }
      /**/
      // $rootScope.owner=response.data.site.owner;
      // $state.go('app.home');
      // $scope.getSitesData(0);

    }, function myError(response) {
      /*alert('failure..'+JSON.stringify(response));*/
      $ionicPopup.show({
        title: 'Alert ',
        cssClass: 'popup-container',
        template: JSON.stringify(response),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },
        ]
      });
    })

  };

  $scope.changePasswordAPI = function (Cpass, Confirmpass) {
    var login_data = {};
    var datas = {
      new_password: Cpass,
      confirm_password: Confirmpass
    };

    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/changepassword",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-Auth-Token': $rootScope.loginToken
      },
      data: $httpParamSerializerJQLike(datas),
      dataType: "json"
    }).then(function mySuccess(response) {
      // alert(JSON.stringify(response));
      if (response.data.error == undefined) {

        // alert("Your password has been updated.");
        /*var alertPopup = $ionicPopup.alert({

                                         title: 'Password Update',
                                         template: 'Your password has been updated.',

                                       });

                                       alertPopup.then(function(res) {

                                         console.log('Thank you for not eating my delicious ice cream cone');
                                       });*/
        $ionicPopup.show({
          title: 'Password Update',
          cssClass: 'popup-container',
          template: 'Your password has been updated.',
          scope: $rootScope,
          buttons: [
            {
              text: 'Thank You',
              onTap: function (e) {
                $scope.goToHome();
              }
            },
          ]
        });
        /*$scope.goTest();*/


      } else {
        //alert(response.data.error.confirm_password);
        $ionicPopup.show({
          title: 'Alert',
          cssClass: 'popup-container',
          template: response.data.error.confirm_password,
          scope: $rootScope,
          buttons: [
            { text: 'Thank You' },
          ]
        });
      }
    }, function myError(response) {
      //alert(JSON.stringify(response));
      $ionicPopup.show({
        title: 'Alert',
        cssClass: 'popup-container',
        template: JSON.stringify(response),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },
        ]
      });
      //$rootScope.elogin=false;



    })

  };

  $scope.slideHasChanged = function (index) {
    //alert('index..'+index);
    console.log(index);
    $rootScope.user_index = index;
    // console.log($rootScope.refresh_user_key);
    //  console.log($rootScope.site_key)

    //  var token1=window.localStorage['clientlogin_username']


    $scope.success_IsVisible = false;
    $scope.error_IsVisible = false;
    /*$rootScope.success_IsVisible_hideloader =false;*/
    $scope.getSitesData(index);
    //$scope.sitedata_power(index);
    $scope.getSitesData_power(index);
    $scope.getSitesData_annualgraph(index);
    $scope.getAllClientsData(index);
    //alert($scope.getSitesData(index));
  };

  /*$scope.sitedata_power=function(index){
   $scope.getSitesData_power(index);
  }*/
  /* $scope.slideHasChanged_annualgraph=function(index){
   $scope.success_IsVisible = false;
          $scope.error_IsVisible = false;
              $rootScope.success_IsVisible_hideloader =false;
            //$scope.getSitesData(index);
           $scope.getSitesData_power(index);
            $scope.getSitesData_annualgraph(index);
   }*/


  /*$scope.showgraph = function(){
  alert("graph click");
  }*/

  /* power graph*/

  /* $scope.powergraph=function(index){
         alert('index..'+index);

           $scope.getSitesData_power_graph(index);
            //alert($scope.getSitesData(index));
            alert($scope.getSitesData_power_graph(index));
          };*/

  $scope.getDisplayValue = function (data) {
    console.log("datavalues===" + data.value);
    console.log("data===" + JSON.stringify(data));

    /* return data.value+' '+data.parameter;*/
    return data.value;

  };
  /*$scope.getDisplayValue_annualgraph = function(data)
     {

        return data.value+' '+data.parameter;

     };*/
  $scope.getSites = function (siteKey) {
    $scope.newKey = siteKey;
    // $scope.newKey="6t2fab696f";
    console.log("site_key" + $scope.newKey);

    /*for(i=0;i<=$scope.newKey.length;i++){
    alert(JSON.stringify(i));
    //$scope.newKey=JSON.stringify(i);
    }*/
    //alert(JSON.stringify($scope.newKey));
    var token = $rootScope.loginToken;


    $http({
      method: "GET",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/sites?site_key=" + $scope.newKey,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Auth-Token': token
      },
      dataType: "json"

    }).then(function mySuccess(response) {
      //console.log('getSites....'+(JSON.stringify(response)));
      /*alert(JSON.stringify(response));*/
      //alert(JSON.stringify(response.data.key.name));

      /*for(i=0;i<=response.data.site.owner.length;i++){
      $rootScope.owner=i;
      }*/
      //$rootScope.owner=response.data.site.owner;
      if ($rootScope.owner !== undefined) {
        $rootScope.owner = response.data.site.owner;
      }

      /*for(i=0;i<=$rootScope.owner.length;i++){
      //alert(JSON.stringify(i));
      $rootScope.owner=i;
      }*/
      //alert(JSON.stringify($rootScope.owner));
      //$rootScope.owner=response.data.site.name; // Rajnish
      //$rootScope.userName=response.data.site.user_name;
      //$rootScope.companyName=response.data.site.user_company_name;
      /*$state.go('app.home');*/
      //$state.go('app.annual_graph');
      //$state.go('app.monitor');
      //$state.go(window.open('http://www.solarsmiths.com', '_blank', 'location=no'));
      /* var today1 = new Date().getHours();
             if (today1>=19 || today1 <= 5) {
                $state.go('app.monitor_night_bg');
             } else {
                   $state.go('app.monitor');
   
             }*/
      $scope.getSitesData(0);
      $scope.getSitesData_power(0);
      $scope.getSitesData_annualgraph(0);
      $scope.getAllClientsData(0);
      //alert(JSON.stringify($scope.getSitesData(0)));


    }, function myError(response) {


    })
  }
  //var outputdata = [];
  //$scope.outputdata1 = ["G","H","J"];
  $scope.getSitesData = function (i) {

    var token = $rootScope.loginToken;
    $rootScope.sitesData = [
      {
        'siteKey': ""
      }
    ];


    var key = $rootScope.sites[i].site_key;
    // var key="6t2fab696f";
    $rootScope.refresh_user_key = $rootScope.sites[i].site_key;
    console.log(key);
    console.log($rootScope.user_index);


    // $http({
    //   method: "GET",
    //   url: "http://103.109.6.71/~clientpro/solarsmith/api/users/sitedetails",
    //   headers: {
    //     'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    //     'X-Auth-Token': window.localStorage['clientlogin_token']
    //   },
    //   dataType: "json"

    // }).then(function mySuccess(response) {
    //   console.log(response.data[0]);
    //   console.log(response.data[key].site_key);
    //   $rootScope.site_key_response = response.data[key].site_key;
    //   console.log($rootScope.site_key_response);
    // })
    // $rootScope.outputdata

    //for (var i = 0; i < (Object.keys($rootScope.sites).length); i++) {
    // $rootScope.sitesData[i].siteKey=$rootScope.sites[i].site_key;


    //alert("key"+key);
    $rootScope.todaydata = [];
    $rootScope.loader();
    console.log("from_date" + $rootScope.last_date);
    console.log("to_date" + $rootScope.today_date);
    // alert(key);
    //alert($rootScope.last_date);
    //alert($rootScope.today_date);
    //var test_url= "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key="+key+"&from_date="+$rootScope.last_date+"&to_date="+$rootScope.today_date+"&time_grouping=day&group_type=max&data_type=Daily Energy";
    //alert(test_url);

    $http({
      method: "GET",
      // url: "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key="+key+"&from_date=22-08-2019&to_date=24-08-2019&time_grouping=day&group_type=max&data_type=Daily Energy",
      // url: "http://103.109.6.71/~clientpro/solarsmith/api/users/energy?site_key=b8b626f8bt&from_date=1575357186&to_date=1575443586&time_grouping=minute&group_type=max",
      //url: "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key="+key+"&from_date="+$rootScope.last_date+"&to_date="+$rootScope.today_date+"&time_grouping=day&group_type=max&data_type=Daily Energy",
      //url: "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key="+key+"&from_date="+$rootScope.last_date+"&to_date="+$rootScope.today_date+"&time_grouping=day&group_type=max&data_type=Daily Energy",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/energytest?site_key=" + key + "&from_date=" + $rootScope.last_date_timestamp + "&to_date=" + $rootScope.today_date_timestamp + "&time_grouping=day&group_type=max",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Auth-Token': token
      },
      dataType: "json"
    }).then(function mySuccess(response) {
      /*$rootScope.success_IsVisible_hideloader =true;*/
      console.log("response====" + JSON.stringify(response));
      //  $ionicLoading.hide();

      $rootScope.showlinechart = false;
      $rootScope.showenergygraph = true;
      $rootScope.showannualchart = false;
      $ionicLoading.hide();
      $rootScope.energychartdata = response.data[$rootScope.sites[i].site_key];


      // $scope.resourceQueryErrFlag1 = true;
      // $scope.outputdata1.unshift(response);

      // document.getElementById("success").style.display = 'none';
      //document.getElementById("success").style.visibility = "hidden";
      //alert(JSON.stringify(response));
      //  alert(JSON.stringify(response.data.error));

      if (response.data.error !== undefined) {
        //if(response.data.key !== undefined && response.data.key.data == "" ){
        //alert('inside else ...error');
        $scope.error_msg = response.data.error;
        if (response.data.error == 'No Data Found.') {
          $scope.nodatafound_error = true;
          $scope.nosolarsystem_error = false;
          $scope.error_IsVisible = true;

        }
        else {
          $scope.nosolarsystem_error = true;
          $scope.nodatafound_error = false;
          $scope.error_IsVisible = true;
        }
        //  alert(JSON.stringify(response.data.error));
        //  $scope.success_IsVisible = false;
        $scope.error_IsVisible = true;

        $rootScope.error_msg = response.data.error;

        //  $scope.success_IsVisible = false;
        $rootScope.error_IsVisible = true;

        //$rootScope.owner = "";
        $rootScope.owner = response.data.name;
        //$rootScope.owner = response.data.site_key.owner;
        $rootScope.alldata = null;
        $rootScope.total_energy = "";
        $rootScope.total_cost = "";
        $rootScope.total_co2 = "";
        $rootScope.total_tree = "";
        $rootScope.total_water = "";





        /*   setTimeout(function(){
             console.log('inside...');
             $scope.error_msg=response.data.error;
              console.log('inside...1');
      //  $scope.success_IsVisible = false;
        $scope.error_IsVisible = true;
       console.log('inside...2');
   }, 2000);*/
        // document.getElementById("error_row").style.display = "block";
        //  alert('inside if after document');
        // document.getElementById("error_row").style.visibility = "hi";
      } else {
        //  alert('inside if ...success');
        //  alert(JSON.stringify(response.data[key].data));
        //  alert(JSON.stringify(response.data[key].name));
        /* $rootScope.success_IsVisible_hideloader =true;*/
        $scope.success_IsVisible = true;
        $scope.error_IsVisible = false;

        $rootScope.success_IsVisible = true;
        $rootScope.error_IsVisible = false;
        //$rootScope.owner=response.data.key.owner;
        //alert(JSON.stringify($rootScope.owner));

        let all_values = [];
        var object = function (order, date1, parameter, value) {
          this.date = date1;
          //console.log("date1="+date1);
          this.parameter = parameter;
          this.value = value;
          this.order = order;
          //console.log("value="+value);
        }
        //alert('inside else after document');
        /*var last = new Date(new Date().getTime() - (4 * 24 * 60 * 60 * 1000));
        for(t=0;t<=4;t++){
          var y= new Date(new Date().getTime() - (t * 24 * 60 * 60 * 1000));*/
        var last = new Date(new Date().getTime() - (4 * 24 * 60 * 60 * 1000));
        for (t = 0; t <= 6; t++) {
          var y = new Date(new Date().getTime() - (t * 24 * 60 * 60 * 1000));

          //console.log(y);
          //console.log(String(last.getDate()).padStart(2, '0'));

          //  console.log(String(y.getDate()).padStart(2, '0'));
          //all_values[t]=new object(String(y.getDate()).padStart(2, '0'),'kWh','0');
          //all_values[t]=new object(String(y.getDate()).padStart(2, '0'),'W',t,'"'+t+'"');
          all_values[t] = new object(t, String(y.getDate()).padStart(2, '0'), 'W', t);
          //   all_values.push("date":""+String(y.getDate()).padStart(2, '0'),"value":""+t);
        }

        // console.log("allvaluesdatasDemo==="+JSON.stringify(all_values));

        //   console.log("allvaluesdatas==="+JSON.stringify(all_values));

        // alert(JSON.stringify(all_values));
        // alert(JSON.stringify(response.data[key].data));
        /*for(p=0;p<response.data[key].data.length;p++){
         console.log(response.data[key].data[p]);
       }*/
        // console.log("allvaluesdatas==="+JSON.stringify(all_values));

        for (k = 0; k < response.data[key].data.length; k++) {
          //console.log(response.data[key].data[k]);
          for (l = 0; l <= all_values.length; l++) {
            //  console.log(l+'...'+all_values[l].date+'..'+String(new Date(response.data[key].data[k].timestamp*1000).getDate()).padStart(2, '0'));

            if (all_values[l].date == String(new Date(response.data[key].data[k].timestamp * 1000).getDate()).padStart(2, '0')) {

              all_values[l].parameter = response.data[key].data[k].unit_of_measure;
              all_values[l].value = response.data[key].data[k].value;
              //console.log("allvaluessss===="+all_values[l].date+"&"+String(new Date(response.data[key].data[k].timestamp*1000).getDate()).padStart(2, '0'));
              break;
            }
          }
        }
        console.log("allvaluesdatas===" + JSON.stringify(all_values));
        $rootScope.owner = response.data[key].name;
        if (response.data[key].data[response.data[key].data.length - 2].value != undefined) {
          // val totalenergy = parseFloat(Math.round((response.data[key].data[response.data[key].data.length-2].value)*10^2)/10^2);
          $rootScope.total_energy = (response.data[key].data[response.data[key].data.length - 2].value).toFixed(2);
          //$rootScope.total_energy = totalenergy;
        } else {
          $rootScope.total_energy = "";
        }

        $rootScope.total_co2 = ($rootScope.total_energy * 0.8).toFixed(2);
        $rootScope.total_cost = ($rootScope.total_energy * 8).toFixed(2);
        $rootScope.total_tree = ($rootScope.total_energy * 22).toFixed(0);
        $rootScope.total_water = ($rootScope.total_energy * 3.5).toFixed(0);
        //var numb = $rootScope.total_co2;
        // numb = numb.toFixed(2);

        //console.log('array...'+JSON.stringify(all_values));
        //alert(JSON.stringify(all_values));
        $rootScope.todaydata = all_values[0];
        //console.log('array...'+JSON.stringify($rootScope.todaydata));
        //all_values.pop(all_values.length-1);
        //all_values.shift();
        //console.log('after array...'+JSON.stringify(all_values));
        //all_values.sort(function (a, b) {
        //return a.order < b.order;
        //});

        $rootScope.alldata = all_values;
        console.log("alldata==" + JSON.stringify($rootScope.alldata));



        /*  for(k=0;k<response.data[key].data.length;k++){
           //  alert(JSON.stringify(response.data[key].data[k].timestamp));
            console.log(response.data[key].data[k]);
            console.log(response.data[key].data[k].timestamp);
           console.log(String(new Date(response.data[key].data[k].timestamp*1000).getDate()).padStart(2, '0'));
          // console.log(JSON.stringify((new Date(response.data[key].data[k].timestamp).getDate().padStart(2, '0')))+'..'+(new Date(response.data[key].data[k].latest_timestamp).getDate().padStart(2, '0')));

              var today = new Date();
              var last = new Date(today.getTime() - (4 * 24 * 60 * 60 * 1000));
            //  alert(today.getTime());
           if(String((new Date(new Date().getTime() - (0 * 24 * 60 * 60 * 1000))).getDate()).padStart(2, '0') == String(new Date(response.data[key].data[k].timestamp*1000).getDate()).padStart(2, '0')){
            alert('today');
            //all_values.push();
           }else   if(String((new Date(new Date().getTime() - (1 * 24 * 60 * 60 * 1000))).getDate()).padStart(2, '0') == String(new Date(response.data[key].data[k].timestamp*1000).getDate()).padStart(2, '0')){
              // alert('yesterday....1');
             // all_dates.push();
           }else   if(String((new Date(new Date().getTime() - (2 * 24 * 60 * 60 * 1000))).getDate()).padStart(2, '0') == String(new Date(response.data[key].data[k].timestamp*1000).getDate()).padStart(2, '0')){
               alert('yesterday...2');
           }else   if(String((new Date(new Date().getTime() - (3 * 24 * 60 * 60 * 1000))).getDate()).padStart(2, '0') == String(new Date(response.data[key].data[k].timestamp*1000).getDate()).padStart(2, '0')){
               alert('yesterday.....3');
           }else   if(String((new Date(new Date().getTime() - (4 * 24 * 60 * 60 * 1000))).getDate()).padStart(2, '0') == String(new Date(response.data[key].data[k].timestamp*1000).getDate()).padStart(2, '0')){
               alert('yesterday.....4');
           }else   if(String((new Date(new Date().getTime() - (5 * 24 * 60 * 60 * 1000))).getDate()).padStart(2, '0') == String(new Date(response.data[key].data[k].timestamp*1000).getDate()).padStart(2, '0')){
               alert('yesterday.....5');
           }
          }*/
      }
      // alert(JSON.stringify(outputdata1));
      // console.log(responce);
      //alert('here...'+i);
      /* alert(i+'....'+(Object.keys($rootScope.sites).length)-1);*/
      /* if(i == 2){
       alert(',,jk..');
                 $scope.outputdata1=outputdata.slice();
                  alert('clone..'+JSON.stringify(outputdata1));
               }*/
    }, function myError(response) {
      //alert(JSON.stringify(response));
      $ionicLoading.hide();
      alert(JSON.stringify(response.data.error));

    })

    // }


    //$state.go('app.home');
  }

  /* added by Rajnish for get power data */

  $scope.getSitesData_power = function (i) {

    var token = $rootScope.loginToken;
    $rootScope.sitesData = [
      {
        'siteKey': ""
      }
    ];


    var key = $rootScope.sites[i].site_key;
    $rootScope.todaydata = [];
    $scope.calculateTodayLastDate(); //  refresh power
    //$interval(calculateTodayLastDate, 5000);
    /*$scope.loader();*/


    $http({
      method: "GET",
      // url: "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key="+key+"&from_date=22-08-2019&to_date=24-08-2019&time_grouping=day&group_type=max&data_type=Daily Energy",
      // url: "http://103.109.6.71/~clientpro/solarsmith/api/users/energy?site_key=b8b626f8bt&from_date=1575357186&to_date=1575443586&time_grouping=minute&group_type=max",
      //url: "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key="+key+"&from_date="+$rootScope.last_date+"&to_date="+$rootScope.today_date+"&time_grouping=day&group_type=max&data_type=Daily Energy",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/power?site_key=" + key + "&from_date=" + $rootScope.from_today_date_timestamp_power + "&to_date=" + $rootScope.today_date_timestamp + "&time_grouping=minute&group_type=max",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Auth-Token': token
      },
      dataType: "json"

    }).then(function mySuccess(response) {


      /*$rootScope.success_IsVisible_hideloader =true;*/
      /*$ionicLoading.hide();*/

      console.log("d1"+JSON.stringify(response));

      if (response.data.error !== undefined) {
        //alert('inside else ...error');
        $scope.error_msg = response.data.error;
        //  alert(JSON.stringify(response.data.error));
        //  $scope.success_IsVisible = false;
        /*$scope.error_IsVisible = true;*/

        /* $rootScope.error_msg=response.data.error;*/
        //  $scope.success_IsVisible = false;
        /*$rootScope.error_IsVisible = true;*/

        //$rootScope.owner = "";
        //$rootScope.owner = response.data.site_key.owner;
        $rootScope.alldata_power = null;

        //all_values = "";



      } else {
        /*$rootScope.success_IsVisible_hideloader =true;*/
        /*$scope.success_IsVisible = true;
        $scope.error_IsVisible = false;
        $rootScope.success_IsVisible = true;
        $rootScope.error_IsVisible = false;*/
        //$rootScope.owner=response.data.key.owner;
        //alert(JSON.stringify($rootScope.owner));

        let all_values = [];
        var object = function (date1, parameter, value) {
          this.date = date1;
          this.parameter = parameter;
          this.value = value;
        }
        //alert('inside else after document');
        var last = new Date(new Date().getTime() - (4 * 24 * 60 * 60 * 1000));
        for (t = 0; t <= 4; t++) {
          var y = new Date(new Date().getTime() - (t * 24 * 60 * 60 * 1000));
          all_values[t] = new object(String(y.getDate()).padStart(2, '0'), 'W', t);
          //   all_values.push("date":""+String(y.getDate()).padStart(2, '0'),"value":""+t);
        }
        if (response.data[key].data != null) {
          for (k = 0; k < response.data[key].data.length; k++) {
            //console.log(response.data[key].data[k]);
            for (l = 0; l <= all_values.length; l++) {
              //  console.log(l+'...'+all_values[l].date+'..'+String(new Date(response.data[key].data[k].timestamp*1000).getDate()).padStart(2, '0'));

              if (all_values[l].date == String(new Date(response.data[key].data[k].timestamp * 1000).getDate()).padStart(2, '0')) {

                all_values[l].parameter = response.data[key].data[k].unit_of_measure;
                /*if(response.data[key].data[k].unit_of_measure=="kWp"){
                all_values[l].value = (response.data[key].data[k].value)*1000;
                }*/

                all_values[l].value = response.data[key].data[k].value;
                //$rootScope.todayallpower_data= JSON.stringify(all_values[l].value);

                $rootScope.todayallpowerdata = JSON.stringify(all_values[l].value);
                //console.log("all values==="+JSON.stringify(all_values[l].value));
                //console.log("all values==="+$rootScope.todayallpowerdata);
                //alert($rootScope.todayallpowerdata);

                //   console.log(JSON.stringify(all_values));
                break;
              }
            }
          }
        }


        //console.log('array power1...'+JSON.stringify(all_values));
        //alert(JSON.stringify(all_values));
        $rootScope.todaydata_power = all_values[0];
        //console.log('array power2...'+JSON.stringify($rootScope.todaydata_power));
        //all_values.pop(all_values.length-1);
        //all_values.shift();
        //console.log('after array power...'+JSON.stringify(all_values));
        $rootScope.alldata_power = all_values;
        console.log("alldatapower===" + JSON.stringify($rootScope.alldata_power[0].value));
        //$rootScope.lables = response.data.map(function(x) { return x.timestamp} )
        $rootScope.dummyChartData = response.data[$rootScope.sites[i].site_key];
        console.log("chart:"+JSON.stringify($rootScope.dummyChartData))

      }

    }, function myError(response) {
      //alert(JSON.stringify(response));
      /*$ionicLoading.hide();*/
      alert(JSON.stringify(response.data.error));

    })

    // }


    //$state.go('app.home');



  }


  /* get annual graph data*/

  $scope.getSitesData_annualgraph = function (i) {

    var today = new Date();
    var from = new Date();
    from.setMonth(from.getMonth() - 4);
    //alert("hello"+today.setDate(0));
    var date = today.getDate();
    //var prvDateMonth = new Date(today.getFullYear(),today.getMonth()-1,today.getDate());
    // var prvDateMonth = new Date(today);
    var fromdate = from.getDate();
    var frommonth = from.getMonth();
    if (frommonth < 10) {
      frommonth = '0' + frommonth;
    }
    var fromyears = from.getFullYear();
    $rootScope.from_date = fromdate + '-' + frommonth + '-' + fromyears;
    //alert("previous"+$rootScope.from_date);
    console.log("fromdate===" + $rootScope.from_date);
    if (date < 10) {
      date = '0' + date;
    }
    //console.log(date);
    var month = today.getMonth() + 1;
    if (month < 10) {
      month = '0' + month;
    }
    //console.log(month);
    var year = today.getFullYear();
    //console.log(year);
    $rootScope.todate = date + '-' + month + '-' + year;
    console.log("todate===" + $rootScope.todate);


    var token = $rootScope.loginToken;
    $rootScope.sitesData = [
      {
        'siteKey': ""
      }
    ];
    var key = $rootScope.sites[i].site_key;
    $rootScope.todaydata = [];
    /*$scope.loader();*/

    $http({
      method: "GET",
      // url: "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key="+key+"&from_date=22-08-2019&to_date=24-08-2019&time_grouping=day&group_type=max&data_type=Daily Energy",
      // url: "http://103.109.6.71/~clientpro/solarsmith/api/users/energy?site_key=b8b626f8bt&from_date=1575357186&to_date=1575443586&time_grouping=minute&group_type=max",
      //url: "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key="+key+"&from_date="+$rootScope.last_date+"&to_date="+$rootScope.today_date+"&time_grouping=day&group_type=max&data_type=Daily Energy",
      //url: "http://103.109.6.71/~clientpro/solarsmith/api/users/energy?site_key="+key+"&from_date="+$rootScope.last_date_timestamp+"&to_date="+$rootScope.today_date_timestamp+"&time_grouping=day&group_type=max",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key=" + key + "&from_date=" + $rootScope.from_date + "&to_date=" + $rootScope.todate + "&time_grouping=month&group_type=max&data_type=Daily Energy",//Total Energy",
      //url: "http://103.109.6.71/~clientpro/solarsmith/api/users/site_summary?site_key="+key+"&from_date=01-09-2019&to_date=29-02-2020&time_grouping=month&group_type=max&data_type=Total Energy",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Auth-Token': token
      },
      dataType: "json"
    }).then(function mySuccess(response) {
      /*$ionicLoading.hide();*/
      //alert(JSON.stringify(response));
      //alert(JSON.stringify(response.data[key].data.value));
      //alert(JSON.stringify(response.data[key].data[0].value));
      //$rootScope.annualchartdata = response.data[$rootScope.sites[i].site_key];
      //$rootScope.annualchartdata = (JSON.stringify(response.data[key].data[0].value));
      $rootScope.annualchartdata = response.data[$rootScope.sites[i].site_key];




    }, function myError(response) {
      //alert(JSON.stringify(response));
      /*$ionicLoading.hide();*/
      alert(JSON.stringify(response.data.error));

    })

  }
  // get all client data
  $scope.getAllClientsData = function (i) {

    var token = $rootScope.loginToken;
    $rootScope.sitesData = [
      {
        'siteKey': ""
      }
    ];


    $rootScope.key = $rootScope.sites[i].site_key;
    //alert("key"+$rootScope.key);
    $rootScope.todaydata = [];


    $http({
      method: "GET",

      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/getAllClientsData?userID=" + $rootScope.user_id,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Auth-Token': token
      },
      dataType: "json"

    }).then(function mySuccess(response) {

      //alert("clientdata"+JSON.stringify(response.data));

      //$rootScope.users=JSON.stringify(response.data.data);
      $rootScope.clientdata = response.data.data;
      $rootScope.clientemail = $rootScope.clientdata[i].email;
      $rootScope.clientphoneno = $rootScope.clientdata[i].user_phone;
      /*alert("clientdata"+$rootScope.clientemail);*/

    }, function myError(response) {
      //alert(JSON.stringify(response));
      /*$ionicLoading.hide();*/
      //alert(JSON.stringify(response.data.error));

    })

  }




  // reset password forgot password

  $scope.resetPassword = function (user_login_id) {


    //alert(user_name);

    var forgot_data = {};
    var datass = {
      user_login_id: user_login_id

    };

    /*if(username.val().length==0 || password.val().length==0){
        alert('Please enter the username');
        return false;
    }
    else{
        if(password.val().length==0)
        {
            alert('Please enter the password');
            return false;
        }
        else
            return true;
    }*/
    //alert(JSON.stringify(datass));

    if (user_login_id == undefined) {
      //alert('Please enter the Email Id OR User Name');
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: 'Please enter the Email Id OR User Name',
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });

    }
    else {
      $http({
        method: "POST",
        url: "http://103.109.6.71/~clientpro/solarsmith/api/users/forget_password",
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: $httpParamSerializerJQLike(datass),
        dataType: "json"
      }).then(function mySuccess(response) {


        if ((response.data.message) == "Please enter valid username/email") {
          //alert(JSON.stringify(response.data.message));
          $ionicPopup.show({
            title: ' Alert',
            cssClass: 'popup-container',
            template: JSON.stringify(response.data.message),
            scope: $rootScope,
            buttons: [
              { text: 'Thank You' },

            ]
          });
        }
        else {
          //alert(JSON.stringify(response.data.message));
          $ionicPopup.show({
            title: ' Reset Password',
            cssClass: 'popup-container',
            template: JSON.stringify(response.data.message),
            scope: $rootScope,
            buttons: [
              { text: 'Thank You' },

            ]
          });
          $state.go('reset_forget_pwd');
        }




      }, function myError(response) {
        alert(JSON.stringify(response));




      })

    }


  };


  // reset password forgot password with otp

  $scope.resetPasswordForget = function (new_pwd, conf_new_pwd, forgot_password_token) {
    //alert(user_name);
    var forgot_data = {};
    var datass = {
      new_pwd: new_pwd,
      conf_new_pwd: conf_new_pwd,
      forgot_password_token: forgot_password_token

    };
    //alert(JSON.stringify(datass));
    if (new_pwd == undefined) {
      //alert('Please enter new password');
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: 'Please enter new password',
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
    }
    else if (conf_new_pwd == undefined) {
      //alert('Please enter Confirmed new password');
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: 'Please Enter Confirmed New Password',
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
    }
    else if (forgot_password_token == undefined) {
      //alert('Please enter Otp');
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: 'Please Enter Otp',
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
    }

    else {


      $http({
        method: "POST",
        url: "http://103.109.6.71/~clientpro/solarsmith/api/users/reset_password",
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: $httpParamSerializerJQLike(datass),
        dataType: "json"
      }).then(function mySuccess(response) {
        //alert(JSON.stringify(response.data.message));


        if (response.data.message == "Please enter correct password/confirm password/otp.") {
          //alert(JSON.stringify(response.data.message));
          $ionicPopup.show({
            title: ' Alert',
            cssClass: 'popup-container',
            template: JSON.stringify(response.data.message),
            scope: $rootScope,
            buttons: [
              { text: 'Thank You' },
            ]
          });
          //$state.go('reset_forget_pwd');
        }
        else {
          //alert(JSON.stringify(response.data.message));
          $ionicPopup.show({
            title: ' Password Updated',
            cssClass: 'popup-container',
            template: JSON.stringify(response.data.message),
            scope: $rootScope,
            buttons: [
              { text: 'Thank You' },
            ]
          });
          $state.go('login');
        }

      }, function myError(response) {
        //alert(JSON.stringify(response));
        $ionicPopup.show({
          title: ' Alert',
          cssClass: 'popup-container',
          template: JSON.stringify(response.data.message),
          scope: $rootScope,
          buttons: [
            { text: 'Thank You' },
          ]
        });

      })
    }


  };

  /*$rootScope.date = function(date){
  return date.getDate()+(date.getDate() % 10 == 1 && date.getDate() != 11 ? 'st' : (date.getDate() % 10 == 2 && date.getDate() != 12 ? 'nd' : (date.getDate() % 10 == 3 && date.getDate() != 13 ? 'rd' : 'th')));
  }


*/

  // signup

  $scope.signup = function (user_phone, user_email_registration, user_password) {
    //alert(user_name);
    var signup_data = {};



    var datass = {
      user_phone: user_phone,
      user_email: user_email_registration,
      user_password: user_password

    };


    //alert(JSON.stringify(datass));

    if (user_phone == undefined) {
      //alert("Please Enter Phone Number");
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: 'Please Enter Phone Number',
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
    } else if (user_email_registration == undefined) {
      //alert("Please Enter Email Id");
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: 'Please Enter Email Id',
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
    }
    else if (user_password == undefined) {
      //alert("Please Enter Password");
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: 'Please Enter Password',
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
    }

    else {


      $http({
        method: "POST",
        url: "http://103.109.6.71/~clientpro/solarsmith/api/users/registration",
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded'
        },
        data: $httpParamSerializerJQLike(datass),
        dataType: "json"
      }).then(function mySuccess(response) {
        //alert(JSON.stringify(response.data.message));
        if ((response.data.status) == false) {
          //alert(JSON.stringify(response.data.message));
          $ionicPopup.show({
            title: ' Alert',
            cssClass: 'popup-container',
            template: JSON.stringify(response.data.message),
            scope: $rootScope,
            buttons: [
              { text: 'Thank You' },

            ]
          });
        }
        else {
          //alert(JSON.stringify(response.data.message));
          $ionicPopup.show({
            title: ' Registration',
            cssClass: 'popup-container',
            template: JSON.stringify(response.data.message),
            scope: $rootScope,
            buttons: [
              { text: 'Thank You' },

            ]
          });
          $state.go('login');
        }

      }, function myError(response) {
        //alert(JSON.stringify(response));
        //alert(JSON.stringify(response.data.message));
        $ionicPopup.show({
          title: ' Alert',
          cssClass: 'popup-container',
          template: JSON.stringify(response.data.message),
          scope: $rootScope,
          buttons: [
            { text: 'Thank You' },

          ]
        });

      })

    }

  };
  var service_type1;
  $scope.showSelectValue = function (mySelect) {
    service_type1 = mySelect.trim();
    console.log(service_type1.length);


  }


  // Service Api

  $scope.serviceAPI = function (description, user_email, user_name, user_phone, service_type) {
    //alert(user_name);
    console.log(service_type1);
    if (service_type1 == undefined) {
      service_type1 = "others"
    }

    var signup_data = {};


    var datass = {
      description: description,
      user_email: $rootScope.user_email,
      user_name: $rootScope.user_name,
      user_phone: $rootScope.userPhoneNo,
      service_type: "Service",
      service_type_problem: service_type1
    };


    //alert("userphone==="+JSON.stringify(datass));



    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/service",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: $httpParamSerializerJQLike(datass),
      dataType: "json"
    }).then(function mySuccess(response) {
      console.log("service data--" + JSON.stringify(datass));
      console.log(JSON.stringify(response.data.message));
      console.log("service data--" + (datass));
      if (description == undefined) {
        $ionicPopup.show({
          title: ' New Service Request',
          cssClass: 'popup-container',
          template: JSON.stringify(response.data.message),
          scope: $rootScope,
          buttons: [
            {
              text: 'Thank You',
              onTap: function (e) {
                //$scope.goToHome();
              }
            },

          ]
        });
      }
      else {
        $ionicPopup.show({
          title: ' New Service Request',
          cssClass: 'popup-container',
          template: JSON.stringify(response.data.message),
          scope: $rootScope,
          buttons: [
            {
              text: 'Thank You',
              onTap: function (e) {
                $scope.goToHome();
              }
            },

          ]
        });
      }
      $ionicLoading.hide();

      // $state.go('app.certificate');
      //$state.go('login');

    }, function myError(response) {
      //alert(JSON.stringify(response));
      //alert(JSON.stringify(response.data.message));
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
      $ionicLoading.hide();

    })



  };


  // online user status Api

  $scope.onlineuserstatus = function () {
    //alert(user_name);
    var useronline_data = {};

    var datass = {
      status: $rootScope.status,
      user_id: $rootScope.user_id


    };
    //alert(JSON.stringify(datass));




    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/onlinestatus",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: $httpParamSerializerJQLike(datass),
      dataType: "json"
    }).then(function mySuccess(response) {
      //alert(JSON.stringify(response.data.message));
      $ionicLoading.hide();


    }, function myError(response) {
      $ionicLoading.hide();
      //alert(JSON.stringify(response));
      //alert(JSON.stringify(response.data.message));

    })
  };

  /* raise ticket API for new customer*/
  $scope.nosolarsystemgetnow = function () {
    //alert("getnowclicked===");

    var useronline_data = {};

    var datass = {
      /*description: "New user request to install the solarsmiths system.",
      *//*user_email: $rootScope.user_email,*//*
      user_email: $rootScope.clientemail,
      user_name:  $rootScope.user_name,
      service_type: "Ticket Raised"*/

      user_name: $rootScope.user_name,
      client_name: $rootScope.owner,
      sitekey: $rootScope.key,
      user_email: $rootScope.clientemail,
      user_phone: $rootScope.clientphoneno,
      description: "New user request to install the solarsmiths system.",
      service_type: "Ticket Raised"


    };
    //alert(JSON.stringify(datass));




    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/get_call",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: $httpParamSerializerJQLike(datass),
      dataType: "json"
    }).then(function mySuccess(response) {
      //alert(JSON.stringify(response.data.message));
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
      $ionicLoading.hide();


    }, function myError(response) {
      //alert(JSON.stringify(response));
      //alert(JSON.stringify(response.data.message));
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
      $ionicLoading.hide();

    })

  };

  // Service Api for raise ticket if no data found since last 7 days

  $scope.nodatafound = function () {
    //alert("name"+$rootScope.owner);
    /*alert("key"+$rootScope.key);*/
    $state.go('app.raise_ticket');
    //clie =$rootScope.owner

    //alert(user_name);
    var signup_data = {};


    /*var datass = {
                     description: "No Data Found Since Last 7 Days",
                     user_email: $rootScope.user_email,
                     user_name:  $rootScope.user_name,
                     service_type: "Ticket Raised"
                   };*/

    /*$http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/service",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: $httpParamSerializerJQLike(datass),
      dataType: "json"
    }).then(function mySuccess(response) {
    //alert(JSON.stringify(response.data.message));

      $ionicPopup.show({
            title: 'Raise Ticket',
            cssClass: 'popup-container',
            template: JSON.stringify(response.data.message),
            scope: $rootScope,
            buttons: [
              { text: 'Thank You' },

            ]
          });

    $ionicLoading.hide();

    // $state.go('app.certificate');
     //$state.go('login');

    }, function myError(response) {
       //alert(JSON.stringify(response));
       //alert(JSON.stringify(response.data.message));
       $ionicPopup.show({
                                        title: ' Alert',
                                       cssClass: 'popup-container',
                                       template: JSON.stringify(response.data.message),
                                       scope: $rootScope,
                                    buttons: [
                                      { text: 'Thank You' },

                                              ]
                                              });
       $ionicLoading.hide();

    })*/



  };
  $scope.submitRaiseTicketData = function (clientName, raiseticketDescription) {
    var signup_data = {};

    var datass = {
      user_name: $rootScope.user_name,
      client_name: $rootScope.owner,
      sitekey: $rootScope.key,
      user_email: $rootScope.clientemail,
      user_phone: $rootScope.clientphoneno,
      description: raiseticketDescription,
      /*user_email: $rootScope.user_email,*/
      service_type: "Ticket Raised"
    };
    //alert("datass"+datass);

    $http({
      method: "POST",
      url: "http://103.109.6.71/~clientpro/solarsmith/api/users/service",
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      data: $httpParamSerializerJQLike(datass),
      dataType: "json"
    }).then(function mySuccess(response) {
      //alert(JSON.stringify(response.data.message));
      if (raiseticketDescription == undefined) {
        $ionicPopup.show({
          title: 'Raise Ticket',
          cssClass: 'popup-container',
          template: JSON.stringify(response.data.message),
          scope: $rootScope,
          buttons: [
            {
              text: 'Thank You',
              onTap: function (e) {
                //  $scope.goToHome();
              }
            },

          ]
        });
      }
      else {
        $ionicPopup.show({
          title: 'Raise Ticket',
          cssClass: 'popup-container',
          template: JSON.stringify(response.data.message),
          scope: $rootScope,
          buttons: [
            {
              text: 'Thank You',
              onTap: function (e) {
                $scope.goToHome();
              }
            },

          ]
        });
      }



      $ionicLoading.hide();

      // $state.go('app.certificate');
      //$state.go('login');

    }, function myError(response) {
      //alert(JSON.stringify(response));
      //alert(JSON.stringify(response.data.message));
      $ionicPopup.show({
        title: ' Alert',
        cssClass: 'popup-container',
        template: JSON.stringify(response.data.message),
        scope: $rootScope,
        buttons: [
          { text: 'Thank You' },

        ]
      });
      $ionicLoading.hide();

    })



  };

  $rootScope.showenergyoutput = function () {
    $rootScope.loader();
    $rootScope.showenergygraph = true;
    $rootScope.showlinechart = false;
    $rootScope.showannualchart = false;
    $ionicLoading.hide();

  }
  $rootScope.showAnnualGraph = function () {
    $rootScope.loader();
    $scope.loadGraph();
    $rootScope.showenergygraph = false;
    $rootScope.showlinechart = false;
    $rootScope.showannualchart = true;
    $ionicLoading.hide();
  }

});

